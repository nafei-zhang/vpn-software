/******/ (() => { // webpackBootstrap
var _window,_window2;// The purpose of this script is: the global plug-in injection is very early, the post message sends the message, the devtools receives the message listener is not running, resulting in the initial data is not available
// To get the initial data, actively get the global variable to send the message
const moduleInfo=(_window=window)===null||_window===void 0||(_window=_window.__FEDERATION__)===null||_window===void 0?void 0:_window.moduleInfo;window.postMessage({moduleInfo,share:JSON.parse(JSON.stringify((_window2=window)===null||_window2===void 0||(_window2=_window2.__FEDERATION__)===null||_window2===void 0?void 0:_window2.__SHARE__,(_key,value)=>{if(typeof value==='function'){return'Function';}return value;}))},'*');
/******/ })()
;