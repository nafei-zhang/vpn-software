/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ../../node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js
function asyncGeneratorStep(n, t, e, r, o, a, c) {
  try {
    var i = n[a](c),
      u = i.value;
  } catch (n) {
    return void e(n);
  }
  i.done ? t(u) : Promise.resolve(u).then(r, o);
}
function _asyncToGenerator(n) {
  return function () {
    var t = this,
      e = arguments;
    return new Promise(function (r, o) {
      var a = n.apply(t, e);
      function _next(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
      }
      function _throw(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
      }
      _next(void 0);
    });
  };
}

;// ./src/utils/chrome/messages.ts
const MESSAGE_OPEN_SIDE_PANEL='mf-devtools/open-side-panel';const MESSAGE_ACTIVE_TAB_CHANGED='mf-devtools/active-tab-changed';
;// ./src/worker/index.ts
const SIDE_PANEL_PATH='html/main/index.html';const getSidePanel=()=>{var _chrome;return(_chrome=chrome)===null||_chrome===void 0?void 0:_chrome.sidePanel;};const resolveTabId=/*#__PURE__*/function(){var _ref=_asyncToGenerator(function*(tabId){if(typeof tabId==='number'){return tabId;}const[activeTab]=yield chrome.tabs.query({active:true,lastFocusedWindow:true});return activeTab===null||activeTab===void 0?void 0:activeTab.id;});return function resolveTabId(_x){return _ref.apply(this,arguments);};}();const broadcastActiveTab=tabId=>{try{chrome.runtime.sendMessage({type:MESSAGE_ACTIVE_TAB_CHANGED,tabId});}catch(error){console.warn('[Module Federation Devtools] Failed to broadcast active tab',error);}};const openSidePanel=/*#__PURE__*/function(){var _ref2=_asyncToGenerator(function*(tabId){const sidePanel=getSidePanel();if(!sidePanel){throw new Error('sidePanel api not available');}const targetTabId=yield resolveTabId(tabId);if(typeof targetTabId!=='number'){throw new Error('No active tab available');}yield sidePanel.setOptions({tabId:targetTabId,path:SIDE_PANEL_PATH,enabled:true});if(sidePanel.open){yield sidePanel.open({tabId:targetTabId});}broadcastActiveTab(targetTabId);if(sidePanel.getOptions){try{const options=yield sidePanel.getOptions({tabId:targetTabId});broadcastActiveTab(targetTabId);return options;}catch(error){console.warn('[Module Federation Devtools] getOptions failed',error);}}return{path:SIDE_PANEL_PATH,enabled:true};});return function openSidePanel(_x2){return _ref2.apply(this,arguments);};}();chrome.runtime.onInstalled.addListener(()=>{const sidePanel=getSidePanel();if(sidePanel!==null&&sidePanel!==void 0&&sidePanel.setPanelBehavior){sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(error=>{console.warn('[Module Federation Devtools] setPanelBehavior failed',error);});}});chrome.action.onClicked.addListener(/*#__PURE__*/function(){var _ref3=_asyncToGenerator(function*(tab){try{yield openSidePanel(tab.id);}catch(error){console.warn('[Module Federation Devtools] Failed to open side panel',error);}});return function(_x3){return _ref3.apply(this,arguments);};}());chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{if((message===null||message===void 0?void 0:message.type)===MESSAGE_OPEN_SIDE_PANEL){openSidePanel(message.tabId).then(options=>sendResponse({ok:true,options})).catch(error=>sendResponse({ok:false,message:String(error)}));return true;}return undefined;});chrome.tabs.onActivated.addListener(/*#__PURE__*/function(){var _ref4=_asyncToGenerator(function*(activeInfo){const tabId=activeInfo===null||activeInfo===void 0?void 0:activeInfo.tabId;if(typeof tabId!=='number'){return;}try{broadcastActiveTab(tabId);}catch(error){console.warn('[Module Federation Devtools] Failed to handle tab activation',error);}});return function(_x4){return _ref4.apply(this,arguments);};}());chrome.tabs.onUpdated.addListener((tabId,changeInfo,tab)=>{if(changeInfo.status!=='complete'){return;}if(tab!==null&&tab!==void 0&&tab.active){try{broadcastActiveTab(tabId);}catch(error){console.warn('[Module Federation Devtools] Failed to handle tab update',error);}}});chrome.tabs.onRemoved.addListener(/*#__PURE__*/function(){var _ref5=_asyncToGenerator(function*(tabId){try{const FormID='FormID';const data=yield chrome.storage.sync.get(FormID);const storeData=data[FormID];if(storeData!==null&&storeData!==void 0&&storeData[String(tabId)]){delete storeData[String(tabId)];yield chrome.storage.sync.set({[FormID]:storeData});}}catch(error){console.warn('[Module Federation Devtools] Failed to handle tab removal',error);}});return function(_x5){return _ref5.apply(this,arguments);};}());console.log('Module Federation Worker ready');
/******/ })()
;