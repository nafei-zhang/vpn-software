﻿
	function sendMessageToContentScript(message) {
	  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
	    const activeTab = tabs[0];
	    chrome.tabs.sendMessage(activeTab.id, message);
	  });
	}

	chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
		console.log("Received a message from content"+message);
	  if (message.action === 'receiveAlertMsg')
	  {
	  	if (message.msg)
	  		$("#msg_content").html(message.msg);
	  	if (message.title)
	  		$("#msg_title").html(message.title);
	  }
	});

	document.getElementById("closebtn").addEventListener("click", function() {
	  var message = { action: "close_win" };
	  sendMessageToContentScript(message);
	});
	
	function getAlertMsg()
	{
		var message = { action: "getAlertMsg"};
		sendMessageToContentScript(message);
		
		var docHeight = Math.max(
		  document.body.scrollHeight, document.documentElement.scrollHeight,
		  document.body.offsetHeight, document.documentElement.offsetHeight,
		  document.body.clientHeight, document.documentElement.clientHeight
	  );
	  
	  var resize_message = { action: "reSize_fav_win",height:docHeight };
	  sendMessageToContentScript(resize_message);
	  
	}
	
	$(document).ready(function(){
		detectAndSetDirection();

		$('#msg_title').text(chrome.i18n.getMessage('msg_title'));

		getAlertMsg();

		$('[data-toggle="tooltip"]').tooltip();
		
		document.addEventListener('contextmenu',function(e){
			e.preventDefault();
		})
	});
	
	
	