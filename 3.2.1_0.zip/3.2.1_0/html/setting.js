﻿	
	function sendMessageToContentScript(message) {
	  	chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
	    	const activeTab = tabs[0];
	    	chrome.tabs.sendMessage(activeTab.id, message);
	  	});
	}

	chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
	  	
	});

	var permissionDownloads = 0;
	function queryPermissionDownloads() {
		chrome.permissions.contains({ permissions: ["downloads"] }, (granted) => {
			if (granted) {
				permissionDownloads = 1;
			} else {
			  chrome.permissions.request({ permissions: ["downloads"] }, (granted) => {
				if (granted) {
					permissionBookmarks = 1;
					chrome.storage.local.set({downloadSaveAs: "yes"}, function() {
						console.log('downloadSaveAs yes');
					});
				} else {
					showTip(chrome.i18n.getMessage('permissionDownloadsDenied'));
					const switchButton = document.getElementById('mySwitch_save_as');
					switchButton.checked = false;
				}
			  });
			}
		});
	}

	function removePermissionDownloads() {
		chrome.permissions.remove({permissions: ['downloads']}, (removed) => {
			if (removed) {
				permissionDownloads = 0;
				console.log('downloads permission removed.');
			} else {
				console.log('Failed to remove downloads permission.');
			}
		});
	}


	function showTip(txt,seconds=2){
		var yeskeeper_win_tip_div = document.createElement("div");
		yeskeeper_win_tip_div.id = "yeskeeper_win_tip_div";
	
		var tipDiv = document.createElement("div");
		tipDiv.style.cssText = "z-index: 2147483645; width: auto; height: auto; position:fixed; top:50%; left:50%; transform: translate(-50%, -50%); background-color: #000; opacity:0.8; padding: 10px 15px 10px 15px; border-radius: 4px; text-align: center; font-size:20px; color:#fff;";
		tipDiv.innerHTML = txt;
	
		yeskeeper_win_tip_div.appendChild(tipDiv);
		document.body.appendChild(yeskeeper_win_tip_div);
		setTimeout(function() {
			let _tipDiv = document.getElementById('yeskeeper_win_tip_div');
			if (_tipDiv)
				document.body.removeChild(_tipDiv);
		},seconds*1000);
	}
	
	function hideTip()
	{
		var yeskeeper_win_tip_div = document.getElementById('yeskeeper_win_tip_div');
		if (yeskeeper_win_tip_div)
			yeskeeper_win_tip_div.remove();
	}

	(function(){
		detectAndSetDirection();
		if (document.documentElement.getAttribute("dir")=="rtl")
		{
			$('.card-body').removeClass('text-left').addClass('text-right');
		}

		$("#name_site").html(chrome.i18n.getMessage('name_site'));
		$("#settings").html(chrome.i18n.getMessage('settings'));

		$("#setting_pdf").html(chrome.i18n.getMessage('setting_pdf'));
		$("#setting_pdf_papersize").html(chrome.i18n.getMessage('setting_pdf_papersize'));
		$("#setting_pdf_papersize_info").html(chrome.i18n.getMessage('setting_pdf_papersize_info'));
		$("#setting_pdf_margin").html(chrome.i18n.getMessage('setting_pdf_margin'));
		$("#setting_pdf_margin_info").html(chrome.i18n.getMessage('setting_pdf_margin_info'));

		$("#setting_download").html(chrome.i18n.getMessage('setting_download'));
		$("#setting_download_save_as").html(chrome.i18n.getMessage('setting_download_save_as'));
		$("#setting_download_save_as_info").html(chrome.i18n.getMessage('setting_download_save_as_info'));
		$("#setting_down_image_format").html(chrome.i18n.getMessage('setting_down_image_format'));
		$("#setting_down_image_format_info").html(chrome.i18n.getMessage('setting_down_image_format_info'));

		$("#setting_filename_set").html(chrome.i18n.getMessage('savedFileNameSet'));
		const savedFileNameSetSelect = document.getElementById("fileNameSet");
		savedFileNameSetSelect.options[0].text = chrome.i18n.getMessage('savedFileNameByTime');
		savedFileNameSetSelect.options[1].text = chrome.i18n.getMessage('savedFileNameByTile');

		const manifest = chrome.runtime.getManifest();
    	document.getElementById('version').textContent = 'V'+manifest.version;

		document.title = chrome.i18n.getMessage('settings') + ' - ' + chrome.i18n.getMessage('name_site');
		
		$('[data-toggle="tooltip"]').tooltip();

		chrome.storage.local.get({ pdfPageSize: 'a4' }, function(items) {
			$("#pdfPageSize").val(items.pdfPageSize);
		});

		$("#pdfPageSize").change(function() { 
			var selectedValue = $(this).val();
			chrome.storage.local.set({pdfPageSize: selectedValue}, function() {
				console.log('pdfPageSize',selectedValue);
				showTip(chrome.i18n.getMessage('fav_success'));
			});	
		});

		chrome.storage.local.get({ pdfPageMargin: '10' }, function(items) {
			$("#pdfPageMargin").val(items.pdfPageMargin);
		});

		$("#pdfPageMargin").change(function() { 
			var selectedValue = $(this).val();
			if (selectedValue>=0 && selectedValue<=40)
			{
				chrome.storage.local.set({pdfPageMargin: selectedValue}, function() {
					console.log('pdfPageMargin',selectedValue);
					showTip(chrome.i18n.getMessage('fav_success'));
				});	
			}
			else{
				showTip('must 0-40');
			}
		});

		chrome.storage.local.get({ downloadImageFormat: 'image/png' }, function(items) {
			$("#downloadImageFormat").val(items.downloadImageFormat);
		});

		$("#downloadImageFormat").change(function() { 
			var selectedValue = $(this).val();
			chrome.storage.local.set({downloadImageFormat: selectedValue}, function() {
				console.log('downloadImageFormat',selectedValue);
				showTip(chrome.i18n.getMessage('fav_success'));
			});	
		});
		
		chrome.storage.local.get({ downloadSaveAs: 'no' }, function(items) {
			if (items.downloadSaveAs==='yes')
			{
				document.getElementById("mySwitch_save_as").checked = true;
			}
			else
			{
				document.getElementById("mySwitch_save_as").checked = false;
			}
		});

		chrome.permissions.contains({ permissions: ["downloads"] }, (granted) => {
			if (granted) {
				permissionDownloads = 1;
			} else {
				permissionDownloads = 0;
			}
		});

		const switchButton_downloadSaveAs = document.getElementById('mySwitch_save_as');
		switchButton_downloadSaveAs.addEventListener('change', function() {
			if (this.checked) {
				if (permissionDownloads==1)
				{
					chrome.storage.local.set({downloadSaveAs: "yes"}, function() {
						console.log('downloadSaveAs yes');
						showTip(chrome.i18n.getMessage('fav_success'));
					});
				}
				else
				{
					queryPermissionDownloads();
				}			
			} else {
				chrome.storage.local.set({downloadSaveAs: "no"}, function() {
					console.log('downloadSaveAs no');
					showTip(chrome.i18n.getMessage('fav_success'));
				});	
			}
		});

		chrome.storage.local.get({ fileNameSet: 'By Time' }, function(items) {
			$("#fileNameSet").val(items.fileNameSet);
			if (items.fileNameSet=='By Time')
				$("#setting_filename_set_info").html(chrome.i18n.getMessage('savedFileNameByTimeInfo'));
			else if (items.fileNameSet=='By Title')
				$("#setting_filename_set_info").html(chrome.i18n.getMessage('savedFileNameByTileInfo'));
		});

		$("#fileNameSet").change(function() { 
			var selectedValue = $(this).val();
			chrome.storage.local.set({fileNameSet: selectedValue}, function() {
				console.log('fileNameSet',selectedValue);
				if (selectedValue=='By Time')
					$("#setting_filename_set_info").html(chrome.i18n.getMessage('savedFileNameByTimeInfo'));
				else if (selectedValue=='By Title')
					$("#setting_filename_set_info").html(chrome.i18n.getMessage('savedFileNameByTileInfo'));
				showTip(chrome.i18n.getMessage('fav_success'));
			});	
		});
		
		document.addEventListener('contextmenu',function(e){
			e.preventDefault();
		})

	})();