﻿var permissionBookmarks = 0;

$('#name_site').text(chrome.i18n.getMessage('name_site'));
$('#name').text(chrome.i18n.getMessage('name'));
$('#description').text(chrome.i18n.getMessage('description'));
$(".msgModalBody").html(chrome.i18n.getMessage('not_support'));
$(".btn-close").text(chrome.i18n.getMessage('close'));
$(document).ready(function(){

	const manifest = chrome.runtime.getManifest();
    document.getElementById('version').textContent = 'V'+manifest.version;
	
	document.title = chrome.i18n.getMessage('name');

	var msg = getQueryParam("msg");
	if (msg && msg==1)
		$('#msgModal').modal('show');

	//$('[data-toggle="tooltip"]').tooltip();

	detectAndSetDirection();
	if (document.documentElement.getAttribute("dir")=="rtl")
	{
		$('#btn_settings').parent().removeClass('text-right').addClass('text-left');
	}

	const userAgent = navigator.userAgent.toLowerCase();
	if (userAgent && userAgent.includes("edg/")) {
		$('#help_pin').attr('src', '../assets/pin_edge.png');
	}
});


function getQueryParam(paramName) {  
	var searchString = window.location.search.substring(1),  
		i, val, params = searchString.split("&");  

	for (i = 0; i < params.length; i++) {  
		val = params[i].split("=");  
		if (val[0] == paramName) {  
			return val[1];  
		}  
	}  
	return null;  
}  

function showTip(txt,seconds=2){
	var capturex_win_tip_div = document.createElement("div");
	capturex_win_tip_div.id = "capturex_win_tip_div";

	var tipDiv = document.createElement("div");
	tipDiv.style.cssText = "z-index: 2147483645; width: auto; height: auto; position:fixed; top:50%; left:50%; transform: translate(-50%, -50%); background-color: #000; opacity:0.8; padding: 10px 15px 10px 15px; border-radius: 4px; text-align: center; font-size:20px; color:#fff;";
	tipDiv.innerText = txt;

	capturex_win_tip_div.appendChild(tipDiv);
	document.body.appendChild(capturex_win_tip_div);
	setTimeout(function() {
		let _tipDiv = document.getElementById('capturex_win_tip_div');
		if (_tipDiv)
			document.body.removeChild(_tipDiv);
	},seconds*1000);
}


