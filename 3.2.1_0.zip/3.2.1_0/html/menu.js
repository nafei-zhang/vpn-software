﻿	
	var activeTab;

	// send message to tab content.js
	function sendMessageToContentScript(message) {
	  	chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
	    	const activeTab = tabs[0];
	    	chrome.tabs.sendMessage(activeTab.id, message);
	  	});
	}

	function callMessageToContentScript(message) {
		return new Promise((resolve, reject) => {
		  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
			const activeTab = tabs[0];
			if (activeTab)
			{
			  chrome.tabs.sendMessage(activeTab.id, message, (response) => {
				if (chrome.runtime.lastError) {
					reject(chrome.runtime.lastError);
				} else {
					resolve(response);
				}
			  });
			}
			else
				not_support();
		  });
		});
	}

	// addListener
	chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
		if (message.action === 'setProgress') {
			showProgress(message.progress);
		}
		else if (message.action === 'closeMenu') {
			window.close();
		}
		else if (message.action === 'showStopBtn') {
			showStopBtn();
		}
		else if (message.action === 'showLoading') {
			showLoading();
		}
		else if (message.action === 'showScrollableAreasBtns') {
			showScrollableAreasBtns(message.num);
		}
		else if (message.action === 'no_scrollableAreas') {
			no_scrollableAreas();
		}
	});

	function showProgress(progress)
	{
		$('#user_page').addClass('d-none');
		$('#scrollable_select_lay').addClass('d-none');
		$('#progress_lay').removeClass('d-none');
		if (progress>100)
			progress = 100;
		if (progress && progress>=0 && progress<=100)
		{
			$('#progressbar').attr('aria-valuenow', progress);
			$('#progressbar').css('width', progress+'%');
		}
	}

	function showLoading()
	{
		if (!$('.stop').hasClass('d-none'))
		{
			$('.stop').removeClass('d-none');
			$('.stop_load').show();
			$('.stop_txt').text(chrome.i18n.getMessage('loading'));
		}
	}

	function showStopBtn()
	{
		$('.stop').removeClass('d-none');
		$('#btn_stop').on('click', function() {
			$('.stop_load').show();
			var message = { action: "stop_captureAllpageEdit" };
			sendMessageToContentScript(message);
		});
	}

	function showScrollableAreasBtns(num=0)
	{
		$('#user_page').addClass('d-none');
		$('#scrollable_select_lay').removeClass('d-none');
		if (num>0)
			$('#scrollable_select_btns').empty();
		
		for (var i=0;i<num;i++)
		{
			$('#scrollable_select_btns').append('<button type="button" id="scrollable_select_'+i+'" data-index="'+i+'" class="btn btn-light w-100 mb-2"><span class="fa fa-cut fa-lg btn-icon mr-2"></span><span>'+chrome.i18n.getMessage('capture_scroll')+'</span></button>');
		}

		for (var i=0;i<num;i++)
		{
			$('#scrollable_select_'+i).on('click', function() {
				if (scrollable_select_cancel_scrollHandler)
				{
					document.removeEventListener('visibilitychange', scrollable_select_cancel_scrollHandler);
					scrollable_select_cancel_scrollHandler =undefined;
				}

				const scrollableIndex = this.getAttribute('data-index');
				chrome.runtime.sendMessage({ action: "reSetData"});
				var message = { action: "capture_scrollable_select",index:scrollableIndex};
				sendMessageToContentScript(message);
				showProgress(0);
			});
	
			$('#scrollable_select_'+i).hover(
				function () {
					const scrollableIndex = this.getAttribute('data-index');
					var message = { action: "scrollable_select_hover_on",index:scrollableIndex};
					sendMessageToContentScript(message);
				},
				function () {
					const scrollableIndex = this.getAttribute('data-index');
					var message = { action: "scrollable_select_hover_off",index:scrollableIndex};
					sendMessageToContentScript(message);
				}
			);
		}

		if (num<3 && num>0)
		{
			$('#scrollable_select_btns').append('<button type="button" id="scrollable_all" class="btn btn-light w-100 mb-2"><span class="fa fa-camera fa-lg btn-icon mr-2"></span><span>'+chrome.i18n.getMessage('captureAllPage')+'</span></button>');
			$('#scrollable_all').on('click', function() {
				if (scrollable_select_cancel_scrollHandler)
				{
					document.removeEventListener('visibilitychange', scrollable_select_cancel_scrollHandler);
					scrollable_select_cancel_scrollHandler =undefined;
				}

				chrome.runtime.sendMessage({ action: "reSetData"});
				var message = { action: "start_captureAllpageEdit" };
				callMessageToContentScript(message)
				.then((response) => {
					if (response && response.loaded !== undefined) { //success
						showProgress(0);
					}
					else
					{
						if (activeTab && activeTab.status!=='complete')
							not_ready();
						else
							not_support();
					}
				})
				.catch((error) => {
					if (activeTab && activeTab.status!=='complete')
						not_ready();
					else
						not_support();
				});
			});
		}

		if (num>0)
		{
			$('#scrollable_select_btns').append('<button type="button" id="scrollable_select_cancel" class="btn btn-light w-100 mb-2"><span>'+chrome.i18n.getMessage('btn_cancel')+'</span></button>');
			$('#scrollable_select_cancel').on('click', function() {
				var message = { action: "scrollable_select_cancel"};
				sendMessageToContentScript(message);
				window.close();
			});
		}

		if (scrollable_select_cancel_scrollHandler == undefined)
		{
			scrollable_select_cancel_scrollHandler = function () {
				if (document.visibilityState === 'hidden') {
					var message = { action: "scrollable_select_cancel"};
					sendMessageToContentScript(message);
				}
			};
			document.addEventListener('visibilitychange', scrollable_select_cancel_scrollHandler);
		}
	}

	var scrollable_select_cancel_scrollHandler;

	function no_scrollableAreas()
	{
		$('#scrollable_select_btns').html(chrome.i18n.getMessage('scrollable_area_no'));
		$('#scrollable_select_btns').append('<button type="button" id="scrollable_all" class="btn btn-light w-100 mt-3 mb-2"><span class="fa fa-camera fa-lg btn-icon mr-2"></span><span>'+chrome.i18n.getMessage('captureAllPage')+'</span></button>');
		$('#scrollable_all').on('click', function() {
			if (scrollable_select_cancel_scrollHandler)
			{
				document.removeEventListener('visibilitychange', scrollable_select_cancel_scrollHandler);
				scrollable_select_cancel_scrollHandler =undefined;
			}

			chrome.runtime.sendMessage({ action: "reSetData"});
			var message = { action: "start_captureAllpageEdit" };
			callMessageToContentScript(message)
			.then((response) => {
				if (response && response.loaded !== undefined) { //success
					showProgress(0);
				}
				else
				{
					if (activeTab && activeTab.status!=='complete')
						not_ready();
					else
						not_support();
				}
			})
			.catch((error) => {
				if (activeTab && activeTab.status!=='complete')
					not_ready();
				else
					not_support();
			});
		});
	}

	function not_support()
	{
		$('.menus').html('<p class="p-2" style="font-size:0.8rem;">'+chrome.i18n.getMessage('not_support')+'</p>');
	}

	function not_ready()
	{
		$('#user_page').addClass('d-none');
		$('#not_ready_lay').removeClass('d-none');
		setTimeout(function() {  
			window.close();
		}, 2000);
	}

	function closeWin()
	{
		window.close();
	}

	(function(){
		chrome.runtime.sendMessage({ action: "checkContentJsIsLoad"});

		detectAndSetDirection();
		if (document.documentElement.getAttribute("dir")=="rtl")
		{
			$('.menus').removeClass('text-left').addClass('text-right');
		}

		$('.capture_allPage').attr("data-original-title", chrome.i18n.getMessage('captureAllPage'));
		$('.capture_page').attr("data-original-title", chrome.i18n.getMessage('capturePage'));
		$('.capture_selection').attr("data-original-title", chrome.i18n.getMessage('captureSelection'));
		$('.local_setting_btn').attr("data-original-title", chrome.i18n.getMessage('settings'));
		$('.report_btn').attr("data-original-title", chrome.i18n.getMessage('reportIssue'));
		
		$('.capture_allPage_txt').text(chrome.i18n.getMessage('captureAllPage'));
		$('.capture_currentPosition_txt').text(chrome.i18n.getMessage('capturePageCurrentPosition'));
		$('.capture_scrollable_txt').text(chrome.i18n.getMessage('captureScrollable'));
		$('.capture_page_txt').text(chrome.i18n.getMessage('capturePage'));
		$('.capture_selection_txt').text(chrome.i18n.getMessage('captureSelection'));
		$('.local_setting_btn_txt').text(chrome.i18n.getMessage('settings'));
		$('.report_btn_txt').text(chrome.i18n.getMessage('reportIssue'));
		$('.not_ready_text').text(chrome.i18n.getMessage('page_not_ready'));
		$('.stop_txt').text(chrome.i18n.getMessage('stop_scrolling'));

		$('[data-toggle="tooltip"]').tooltip();

		chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
	    	activeTab = tabs[0];
	  	});

		$('.capture_allPage').on('click', function() {
			chrome.runtime.sendMessage({ action: "reSetData"});
			var message = { action: "start_captureAllpageEdit" };
			callMessageToContentScript(message)
			.then((response) => {
				if (response && response.loaded !== undefined) { //success
					showProgress(0);
				}
				else
				{
					if (activeTab && activeTab.status!=='complete')
						not_ready();
					else
						not_support();
				}
			})
			.catch((error) => {
				if (activeTab && activeTab.status!=='complete')
					not_ready();
				else
					not_support();
			});
		});

		$('.capture_currentPosition').on('click', function() {
			chrome.runtime.sendMessage({ action: "reSetData"});
			var message = { action: "start_capturePageFromCurrentPosition" };
			callMessageToContentScript(message)
			.then((response) => {
				if (response && response.loaded !== undefined) { //success
					showProgress(0);
				}
				else
				{
					if (activeTab && activeTab.status!=='complete')
						not_ready();
					else
						not_support();
				}
			})
			.catch((error) => {
				if (activeTab && activeTab.status!=='complete')
					not_ready();
				else
					not_support();
			});
		});

		$('.capture_page').on('click', function() {
			chrome.runtime.sendMessage({ action: "reSetData"});
			var message = { action: "capturePageEdit" };
			callMessageToContentScript(message)
			.then((response) => {
				if (response && response.loaded !== undefined) { //success
					window.close();
				}
				else
				{
					if (activeTab && activeTab.status!=='complete')
						not_ready();
					else
						not_support();
				}
			})
			.catch((error) => {
				if (activeTab && activeTab.status!=='complete')
					not_ready();
				else
					not_support();
			});
		});

		$('.capture_scrollable').on('click', function() {
			chrome.runtime.sendMessage({ action: "reSetData"});
			var message = { action: "captureScrollableEdit" };
			callMessageToContentScript(message)
			.then((response) => {
				if (response && response.loaded !== undefined) { //success
					showScrollableAreasBtns(0);
				}
				else
				{
					if (activeTab && activeTab.status!=='complete')
						not_ready();
					else
						not_support();
				}
			})
			.catch((error) => {
				if (activeTab && activeTab.status!=='complete')
					not_ready();
				else
					not_support();
			});
		});

		$('.capture_selection').on('click', function() {
			chrome.runtime.sendMessage({ action: "reSetData"});
			var message = { action: "captureSelectionEdit" };
			callMessageToContentScript(message)
			.then((response) => {
				if (response && response.loaded !== undefined) { //success
					window.close();
				}
				else
				{
					if (activeTab && activeTab.status!=='complete')
						not_ready();
					else
						not_support();
				}
			})
			.catch((error) => {
				if (activeTab && activeTab.status!=='complete')
					not_ready();
				else
					not_support();
			});
		});

		$('.local_setting_btn').on('click', function() {
			try {
				chrome.tabs.create({ url: chrome.runtime.getURL("html/setting.html") });
			} catch (e) {}
		});

		$('.report_btn').on('click', function() {
			var message = { action: "showReportWin" };
			callMessageToContentScript(message)
			.then((response) => {
				if (response && response.loaded !== undefined) { //success
					window.close();
				}
				else
				{
					if (activeTab && activeTab.status!=='complete')
						not_ready();
					else
						not_support();
				}
			})
			.catch((error) => {
				if (activeTab && activeTab.status!=='complete')
					not_ready();
				else
					not_support();
			});
		});

		//disable right click
		// document.addEventListener('contextmenu',function(e){
		// 	e.preventDefault();
		// });

	})();
