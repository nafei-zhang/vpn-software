﻿
	function sendMessageToContentScript(message) {
	  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
	    const activeTab = tabs[0];
	    chrome.tabs.sendMessage(activeTab.id, message);
	  });
	}

	chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
	  if (message.action === 'receiveUrl')
	  {
	  	if (message.url)
			$('#issue_url').val(message.url);
	  }
	});

	document.getElementById("closebtn").addEventListener("click", function() {
	  var message = { action: "close_win" };
	  sendMessageToContentScript(message);
	});
	
	function getUrl()
	{
		var message = { action: "getUrl"};
		sendMessageToContentScript(message);
		
		var docHeight = Math.max(
			document.body.scrollHeight, document.documentElement.scrollHeight,
			document.body.offsetHeight, document.documentElement.offsetHeight,
			document.body.clientHeight, document.documentElement.clientHeight
		);
		
		var resize_message = { action: "reSize_win",height:docHeight };
		sendMessageToContentScript(resize_message);
	}

	function addIssue(){
		if ($('#issue_title').val()=='')
		{
			$('#doInfo').text(chrome.i18n.getMessage('issueTitleAdd'));
			$('#issue_title').focus();
		}
		else if ($('#issue_body').val()=='')
		{
			$('#doInfo').text(chrome.i18n.getMessage('issueContentAdd'));
			$('#issue_body').focus();
		}
		else if ($('#issue_email').val()=='')
		{
			$('#doInfo').text(chrome.i18n.getMessage('issueEmail'));
			$('#issue_email').focus();
		}
		else
		{
			document.getElementById('btn_submit').disabled = true;
			$('#doInfo').html('<i class="fa fa-spinner fa-pulse"></i>');
			var formData = $("#addIssueForm").serialize();
			$.ajax({
				type: "POST",
				url: "https://yeskeeper.com/doc/AddIssueAction.do",
				cache: false,
				data: formData,
				success: function(data){
					document.getElementById('btn_submit').disabled = false;
					if (data.rtn==1)
					{
						document.getElementById('doInfo').innerText = 'Success, Thanks!';

						setTimeout(function() {  
							var message = { action: "close_win"};
							sendMessageToContentScript(message);
						}, 2000);
					}
					else
					{
						document.getElementById('doInfo').innerText = data.msg;
					}
				},
				error: function(data){
					var msg_content = chrome.i18n.getMessage("net_error");
					document.getElementById('doInfo').innerText = msg_content;
					document.getElementById('btn_submit').disabled = false;
				}
			});
		}
	}
	
	$(document).ready(function(){
		detectAndSetDirection();
		if (document.documentElement.getAttribute("dir")=="rtl")
		{
			$('#closebtn').css('right', '').css('left', '16px');
			$('.card-header').removeClass('text-left').addClass('text-right');
		}

		$('#msg_title').text(chrome.i18n.getMessage('reportIssue'));
		$('#issue_title').attr('placeholder', chrome.i18n.getMessage('issueTitleAdd'));
		$('#issue_body').attr('placeholder', chrome.i18n.getMessage('issueContentAdd'));
		$('#issue_url').attr('placeholder', chrome.i18n.getMessage('issueUrl'));
		$('#issue_email').attr('placeholder', chrome.i18n.getMessage('issueEmail'));
		$('#btn_submit').text(chrome.i18n.getMessage('btn_submit'));
		$('.issue_link_text').text(chrome.i18n.getMessage('issueUrl'));
		$('.issue_email_text').text(chrome.i18n.getMessage('issueEmail'));

		const manifest = chrome.runtime.getManifest();
		$('#version').val(manifest.version);

		$('#issue_title').focus();

		getUrl();
		
		$("#btn_submit").on("click", function () {
			addIssue();
		});

		$('[data-toggle="tooltip"]').tooltip();
		
		// document.addEventListener('contextmenu',function(e){
		// 	e.preventDefault();
		// })
	});