﻿var firstLoad = 1;
var pageHtml;
var isLogin = 0; 
var doing = 0; 
var screenshotNum = 0;
var annotateImgIndex = 0;
var screenshotMaxNum = 8;

var zoomLevel = window.devicePixelRatio;
var viewThumbnail = 0;
var thumbnailWidth = 200;

$('#btn_mark').attr('title', chrome.i18n.getMessage('captureAnnotate'));
$('#btn_copy').attr('title', chrome.i18n.getMessage('copyToClipBoard'));
$('#btn_crop').attr('title', chrome.i18n.getMessage('crop'));
$('#btn_download').attr('title', chrome.i18n.getMessage('captureDownload'));
$('#btn_pdf').attr('title', chrome.i18n.getMessage('capture2pdfDownload'));
$('#btn_print').attr('title', chrome.i18n.getMessage('print'));
$('#btn_set').attr('title', chrome.i18n.getMessage('settings'));
$('#btn_report').attr('title', chrome.i18n.getMessage('reportIssue'));

$('.name_site').text(chrome.i18n.getMessage('name_site'));
//$('#captureClickAnnotate').text(chrome.i18n.getMessage('captureClickAnnotate'));

const manifest = chrome.runtime.getManifest();
$('#version').text('V'+manifest.version);

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.action === 'sendScreenshot0') {
		console.log("get sendScreenshot0",message.data.length);
        var screenshot_source = document.getElementById('screenshot0_source');
        var screenshot = document.getElementById('screenshot0');
        screenshot_source.src = message.data;
        screenshot.src = message.data;
        screenshotNum = 1;
		var div_screenshot0 = document.getElementById('div_screenshot0');
		div_screenshot0.style.display='block';
    }
    else if (message.action === 'sendScreenshot1') {
		console.log("get sendScreenshot1",message.data.length);
		var screenshot_source = document.getElementById('screenshot1_source');
		var screenshot = document.getElementById('screenshot1');
		screenshot_source.src = message.data;
		screenshot.src = message.data;
		screenshotNum = 2;
		showTip(chrome.i18n.getMessage('splitMultiImages'),4);
		var div_screenshot1 = document.getElementById('div_screenshot1');
		div_screenshot1.style.display='block';
		viewThumbnail = 1;
	}
	else if (message.action === 'sendScreenshot2') {
		console.log("get sendScreenshot2",message.data.length);
		var screenshot_source = document.getElementById('screenshot2_source');
		var screenshot = document.getElementById('screenshot2');
		screenshot_source.src = message.data;
		screenshot.src = message.data;
		screenshotNum = 3;
		var div_screenshot2 = document.getElementById('div_screenshot2');
		div_screenshot2.style.display='block';
		viewThumbnail = 1;
	}
	else if (message.action === 'sendScreenshot3') {
		console.log("get sendScreenshot3",message.data.length);
		var screenshot_source = document.getElementById('screenshot3_source');
		var screenshot = document.getElementById('screenshot3');
		screenshot_source.src = message.data;
		screenshot.src = message.data;
		screenshotNum = 4;
		var div_screenshot3 = document.getElementById('div_screenshot3');
		div_screenshot3.style.display='block';
		viewThumbnail = 1;
	}
	else if (message.action === 'sendScreenshot4') {
		console.log("get sendScreenshot4",message.data.length);
		var screenshot_source = document.getElementById('screenshot4_source');
		var screenshot = document.getElementById('screenshot4');
		screenshot_source.src = message.data;
		screenshot.src = message.data;
		screenshotNum = 5;
		var div_screenshot4 = document.getElementById('div_screenshot4');
		div_screenshot4.style.display='block';
		viewThumbnail = 1;
	}
	else if (message.action === 'sendScreenshot5') {
		console.log("get sendScreenshot5",message.data.length);
		var screenshot_source = document.getElementById('screenshot5_source');
		var screenshot = document.getElementById('screenshot5');
		screenshot_source.src = message.data;
		screenshot.src = message.data;
		screenshotNum = 6;
		var div_screenshot5 = document.getElementById('div_screenshot5');
		div_screenshot5.style.display='block';
		viewThumbnail = 1;
	}
	else if (message.action === 'sendScreenshot6') {
		console.log("get sendScreenshot6",message.data.length);
		var screenshot_source = document.getElementById('screenshot6_source');
		var screenshot = document.getElementById('screenshot6');
		screenshot_source.src = message.data;
		screenshot.src = message.data;btn_download
		screenshotNum = 7;
		var div_screenshot6 = document.getElementById('div_screenshot6');
		div_screenshot6.style.display='block';
		viewThumbnail = 1;
	}
	else if (message.action === 'sendScreenshot7') {
		console.log("get sendScreenshot7",message.data.length);
		var screenshot_source = document.getElementById('screenshot7_source');
		var screenshot = document.getElementById('screenshot7');
		screenshot_source.src = message.data;
		screenshot.src = message.data;
		screenshotNum = 8;
		var div_screenshot7 = document.getElementById('div_screenshot7');
		div_screenshot7.style.display='block';
		viewThumbnail = 1;
	}
    else if (message.action === 'page_data')
    {
        if (message.url)
        {
            document.getElementById('fav_urltitle').value =  truncateString(message.title, 100);
            document.getElementById('fav_url').value =  message.url;
            var pageTitle = 'CaptureX - '+ truncateString(message.title, 40) + ' - ' + getDomainFromUrl(message.url);
            document.title = pageTitle;
            pageHtml = message.pageHtml;
        }
    }
	else if (message.action === 'showReportWin') {
		showReportWin();
		sendResponse({ loaded: true });
	} 
	else if (message.action === 'getUrl') {
		chrome.runtime.sendMessage({ action: "receiveUrl",url:document.getElementById('fav_url').value});
	}
	else if (message.action === 'close_win') {
		closeWin();
	}
});

let cropArea;
function showCropArea(target,index=0) {
	if (cropArea && cropArea.isOpen)
		return;

	var sourceImagesData;
	if (maStates[index])
	{
		sourceImagesData = sourceImages[index].src;
		sourceImages[index].src=target.src;
	}
	
	if (markerAreas[index] && markerAreas[index].isOpen)
		markerAreas[index].close();

	cropArea = new cropro.CropArea(sourceImages[index]);
	//cropArea = new cropro.CropArea(target);
	cropArea.renderAtNaturalSize = true;
	cropArea.zoomToCropEnabled = false;
	//cropArea.displayMode = 'popup';
	cropArea.styles.settings.hideTopToolbar = true;
	cropArea.styles.settings.hideBottomToolbar = true;
	cropArea.styles.settings.cropShadeColor = '#333333';
	cropArea.styles.settings.cropFrameColor = '#5c5c5c';
	cropArea.addRenderEventListener((imgURL) => target.src = imgURL);
	cropArea.show();

	var bottomBar = $('<div class="fixed-bottom-bar"></div>');
    var button1 = $('<button type="button" class="btn btn-primary btn-crop-ok">'+chrome.i18n.getMessage('btn_ok')+'</button>');
    var button2 = $('<button type="button" class="btn btn-primary btn-crop-cancel">'+chrome.i18n.getMessage('btn_cancel')+'</button>');
    bottomBar.append(button1).append(button2);
	bottomBar.append('<a href="https://markerjs.com/products/cropro" target="_blank" style="color: currentcolor;position: fixed;z-index: 10001; bottom: 10px;right: 10px;"><svg viewBox="0 0 24 24" style="height:20px;" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2"><path d="M16.326 14.895c0 1.126-.558 1.688-1.673 1.688H9.931c-1.116 0-1.674-.562-1.674-1.688V3.733c0-1.126.558-1.688 1.674-1.688h4.722c1.115 0 1.673.562 1.673 1.688v2.899h-1.957V3.793h-4.124v11.042h4.124v-3.242h1.957v3.302z" fill="currentColor"></path><path d="M15.94 7.364a.783.783 0 00-1.065-.304l-11.01 6.126a.783.783 0 00-.303 1.065l4.498 8.085a.783.783 0 001.065.304l11.01-6.126a.783.783 0 00.303-1.065L15.94 7.364zM5.311 14.173l3.737 6.718 9.641-5.364-3.737-6.718-9.641 5.364z" fill="#eef762"></path></svg></a>');
	
    $('body').append(bottomBar); 
	button1.click(function() { 
		if (cropArea && cropArea.isOpen) {
			$(".btn-crop-ok").prepend('<span class="fa fa-spinner fa-spin fa-lg mr-1"></span>');

			setTimeout(function() {
				cropArea.startRenderAndClose();
			},200);

			setTimeout(function() {
				reSize();
			},500);
			
			setTimeout(function() {
				$("#screenshot"+index+"_source").attr('src',$("#screenshot"+index).attr('src'));
				if (openState[index])
					openState[index] = 0;
				if (maStates[index])
					maStates[index] = undefined;

				bottomBar.remove();
			},1000);
		}
		else
		{
			bottomBar.remove();
		}
    });

	button2.click(function() { 
		if (cropArea && cropArea.isOpen) {
			cropArea.close();
		}
		if (sourceImagesData)
		{
			sourceImages[index].src=sourceImagesData;
		}
		bottomBar.remove();
    });
}

var openState = Array(screenshotMaxNum).fill(0);

var sourceImages = {}, targetRoots = {}, maStates = {}, markerAreas = {};
function setSourceImage(id, source) {
    sourceImages[id] = source;
    targetRoots[id] = source.parentElement;
}

function showMarkerAreaEdit(id=0, target) {
	if (target.width<500 && window.innerWidth>500)
	{
		let screenshot_source = document.getElementById('screenshot' + id + '_source');
		let screenshot = document.getElementById('screenshot' + id);
		let img_width = 500;
		let img_height = screenshot.naturalHeight/screenshot.naturalWidth*img_width;
		screenshot.style.width = img_width + 'px';
		screenshot.style.height = img_height + 'px';
		img_width = screenshot.width;
		img_height = screenshot.height;

		let rect = screenshot.getBoundingClientRect();
		screenshot_source.style.top = rect.top + window.scrollY + 'px';
		screenshot_source.style.left = rect.left + 'px';
		screenshot_source.style.width = img_width + 'px';
		screenshot_source.style.height = img_height + 'px';
		screenshot_source.style.display = 'block';
	}

    markerAreas[id] = new markerjs2.MarkerArea(sourceImages[id]);
    markerAreas[id].availableMarkerTypes = markerAreas[id].ALL_MARKER_TYPES;
    
	if (target.width>=500)
	{
		markerAreas[id].uiStyleSettings.redoButtonVisible = true;
    	markerAreas[id].uiStyleSettings.notesButtonVisible = true;
		markerAreas[id].uiStyleSettings.zoomButtonVisible = true;
		markerAreas[id].uiStyleSettings.zoomOutButtonVisible = true;
		markerAreas[id].uiStyleSettings.clearButtonVisible = true;
		markerAreas[id].renderAtNaturalSize = true;
	}
    
    if (sourceImages[id] && sourceImages[id].src.indexOf('data:image/jpeg;') === 0) {
        markerAreas[id].renderImageType = 'image/jpeg';
    }

    markerAreas[id].addEventListener('render', (event) => {
        target.src = event.dataUrl;
        maStates[id] = event.state;
    });
    
    markerAreas[id].show();
    openState[id] = 1;
    
    if (maStates[id]) {
        markerAreas[id].restoreState(maStates[id]);
    }

    markerAreas[id].addEventListener("close", (event) => {
        openState[id] = 0;
        setTimeout(() => {
            reSize();
        }, 800);
        event.preventDefault();
    });
}


function reSize()
{
	for (let i = 0; i < screenshotNum; i++) {
		let screenshot_source = document.getElementById('screenshot' + i + '_source');
		let screenshot = document.getElementById('screenshot' + i);
		let div_screenshot = document.getElementById(`div_screenshot${i}`);

		if (screenshot && screenshot_source) {
			screenshot.style.removeProperty('width');
			screenshot.style.removeProperty('height');
			screenshot_source.style.removeProperty('width');
			screenshot_source.style.removeProperty('height');

			let img_width;
			let img_height;
			if (screenshot.naturalWidth/zoomLevel<div_screenshot.clientWidth-20)
			{
				img_width=screenshot.naturalWidth/zoomLevel;
				img_height=screenshot.naturalHeight/zoomLevel;
				screenshot.style.width = img_width + 'px';
				screenshot.style.height = img_height + 'px';
			}
			else
			{
				img_width = screenshot.width;
				img_height = screenshot.naturalHeight*img_width/screenshot.naturalWidth;
				screenshot.style.width = img_width + 'px';
				screenshot.style.height = img_height + 'px';
			}

			let rect = screenshot.getBoundingClientRect();
			screenshot_source.style.top = rect.top + window.scrollY + 'px';
			screenshot_source.style.left = rect.left + 'px';
			screenshot_source.style.width = img_width + 'px';
			screenshot_source.style.height = img_height + 'px';
			screenshot_source.style.display = 'block';
			
		}
	}
}

window.addEventListener('resize', function(event) {  
    reSize();
});

function setScreenshotSourceSize()
{
	//console.log('setScreenshotSourceSize');
	for (let i = 0; i <= screenshotNum; i++) {

		let screenshot_source = document.getElementById(`screenshot${i}_source`);
		let screenshot = document.getElementById(`screenshot${i}`);

		let img_width;
		let img_height;

		img_width = screenshot.width;
		img_height = screenshot.height;
		let rect = screenshot.getBoundingClientRect();
		screenshot_source.style.top = rect.top +  window.scrollY + 'px';
		screenshot_source.style.left = rect.left + 'px';
		screenshot_source.style.width = img_width + 'px';
		screenshot_source.style.height = img_height + 'px';
		screenshot_source.style.display = 'block';
	}
}

function zoomImgs(i=0)
{
	if (viewThumbnail==1)
	{
		let screenshot_container = document.getElementById('screenshot-container');
		screenshot_container.classList.remove('flex-row');
		screenshot_container.classList.remove('flex-wrap');
		screenshot_container.classList.remove('justify-content-center');
		screenshot_container.classList.add('flex-column');

		for (let i = 0; i <= screenshotNum; i++)
		{
			let screenshot = document.getElementById(`screenshot${i}`);
			let screenshot_source = document.getElementById(`screenshot${i}_source`);
			screenshot.style.cursor = 'zoom-out';
			let img_width=screenshot.naturalWidth/zoomLevel;
			let img_height=screenshot.naturalHeight/zoomLevel;
			screenshot.style.width = img_width + 'px';
			screenshot.style.height = img_height + 'px';
			screenshot_source.style.display='none';
		}

		for (let i = 0; i <= screenshotNum; i++)
		{
			let screenshot = document.getElementById(`screenshot${i}`);
			let screenshot_source = document.getElementById(`screenshot${i}_source`);
			let img_width = screenshot.width;
			let img_height = screenshot.height;
			let rect = screenshot.getBoundingClientRect();
			screenshot_source.style.top = rect.top +  window.scrollY + 'px';
			screenshot_source.style.left = rect.left + 'px';
			screenshot_source.style.width = img_width + 'px';
			screenshot_source.style.height = img_height + 'px';
			screenshot_source.style.display='block';
		}

		if (i>0)
		{
			let element = document.getElementById(`screenshot${i}`);
			if (element) {
				element.scrollIntoView({
					behavior: 'auto',
					block: 'start'
				}); 
			} 
		}
		else
		{
			window.scrollTo({top: 0});
		}

		viewThumbnail = 0;
		reSize();
	}
	else{
		let screenshot_container = document.getElementById('screenshot-container');
		screenshot_container.classList.remove('flex-column');
		screenshot_container.classList.add('flex-row', 'flex-wrap', 'justify-content-center');

		for (let i = 0; i <= screenshotNum; i++) {
			let screenshot = document.getElementById(`screenshot${i}`);
			let img_width;
			let img_height;
			if (thumbnailWidth<screenshot.naturalWidth/zoomLevel)
			{
				img_width = thumbnailWidth;
				img_height = screenshot.naturalHeight/screenshot.naturalWidth*img_width;
			}
			else
			{
				img_width=screenshot.naturalWidth/zoomLevel;
				img_height=screenshot.naturalHeight/zoomLevel;
			}
			
			screenshot.style.width = img_width + 'px';
			screenshot.style.height = img_height + 'px';
			screenshot.style.display='block';
			screenshot.style.cursor='zoom-in';
		}

		for (let i = 0; i <= screenshotNum; i++)
		{
			let screenshot = document.getElementById(`screenshot${i}`);
			let screenshot_source = document.getElementById(`screenshot${i}_source`);
			let img_width = screenshot.width;
			let img_height = screenshot.height;
			let rect = screenshot.getBoundingClientRect();
			screenshot_source.style.top = rect.top +  window.scrollY + 'px';
			screenshot_source.style.left = rect.left + 'px';
			screenshot_source.style.width = img_width + 'px';
			screenshot_source.style.height = img_height + 'px';
			screenshot_source.style.display='block';
		}

		window.scrollTo({top: 0});  
		viewThumbnail = 1;
	}
}

$(document).ready(function(){
	detectAndSetDirection();
	if (document.documentElement.getAttribute("dir")=="rtl")
	{
		$('.imgMenus').removeClass('text-right').addClass('text-left');
	}

    window.scrollTo({top: 0});

	for (let i = 0; i <= screenshotMaxNum; i++) {
		$(`#screenshot${i}`).on('load', function() {
			if (viewThumbnail==1)
			{
				let screenshot_container = document.getElementById('screenshot-container');
				screenshot_container.classList.remove('flex-column');
				screenshot_container.classList.add('flex-row', 'flex-wrap', 'justify-content-center');
			}

			let screenshot = document.getElementById(`screenshot${i}`);
			let div_screenshot = document.getElementById(`div_screenshot${i}`);

			let img_width;
			let img_height;
			if (screenshot.naturalWidth/zoomLevel<div_screenshot.clientWidth-20)
			{
				img_width=screenshot.naturalWidth/zoomLevel;
				img_height=screenshot.naturalHeight/zoomLevel;
				screenshot.style.width = img_width + 'px';
				screenshot.style.height = img_height + 'px';
				screenshot.style.display='block';
			}
			else
			{
				if (viewThumbnail==1)
				{
					if (thumbnailWidth<screenshot.naturalWidth/zoomLevel)
					{
						img_width = thumbnailWidth;
						img_height = screenshot.naturalHeight/screenshot.naturalWidth*img_width;
					}
					else
					{
						img_width=screenshot.naturalWidth/zoomLevel;
						img_height=screenshot.naturalHeight/zoomLevel;
					}
					
					screenshot.style.width = img_width + 'px';
					screenshot.style.height = img_height + 'px';
					screenshot.style.display='block';
					screenshot.style.cursor='zoom-in';
				}
				else
				{
					screenshot.style.display='block';
					//maybe srollbar display, img width is changed
					img_width = screenshot.width;
					img_height = screenshot.height;
					screenshot.style.width = img_width + 'px';
					screenshot.style.height = img_height + 'px';
				}

			}
			firstLoad = 0;

			if (i==(screenshotNum-1))
				setScreenshotSourceSize();
		});
	
		$(`#screenshot${i}_source`).on('load', function() {
			setSourceImage(i,this);
		});
	}

    //showSave2yeskeeperForm();
    //checkUser();

    showTip(chrome.i18n.getMessage('loading'));
    setTimeout(function() {
		chrome.runtime.sendMessage({ action: "query_sendScreenshot"});
	},100);

    setTimeout(function() {
		addBtnClickListener();
	},1000);

    $('[data-toggle="tooltip"]').tooltip();

	chrome.storage.local.get({ useTimes: 1 }, function(items) {
		let _useTimes = items.useTimes;
		if (_useTimes===6 || _useTimes===20)
		{
			showRightWin();
		}
		chrome.storage.local.set({useTimes: _useTimes+1}, function() {});
	});

    // document.addEventListener('contextmenu',function(e){
    // 	e.preventDefault();
    // })
});

function addBtnClickListener() {
	if (screenshotNum==1)
	{
		$('#screenshot0').on('click', function() {
			showMarkerAreaEdit(0,this);
		});

		$('#btn_mark').on('click', function() {
			var elements = document.getElementsByClassName('__markerjs2_');
			if (elements.length==0)
			{
				showMarkerAreaEdit(0,document.getElementById('screenshot0'));
				//$('#screenshot0').trigger('click');
			}
		});

		$('#btn_crop').on('click', function() {
			//console.log('crop');
			let _screenshot = document.getElementById('screenshot0');
			if (_screenshot && _screenshot.offsetHeight>9000)
			{
				//console.log("big image");
				showCropArea(_screenshot);
			}
			else if (_screenshot)
			{
				showCropArea(_screenshot);
			}
		});

		$('#btn_copy').on('click', function() {
			if (doing==0)
			{
				doing = 1;
				$('.icon_copy_load').show();
				$('.icon_copy').hide();
				if (openState[0] == 1)
				{
					markerAreas[0].startRenderAndClose().then(result => {
						btn_copy_action();
					}).catch(error => { console.error(error); });
				}
				else {
					btn_copy_action();
				}
				setTimeout(function() {
					doing = 0;
					$('.icon_copy_load').hide();
					$('.icon_copy').show();
				},5000);
			}
		});
	}
	else if (screenshotNum>1)
	{
		$("#btn_mark").hide();
		$("#btn_copy").hide();
		$("#btn_crop").hide();
		$("#btns_mark").show();
		$("#btns_copy").show();
		$("#btns_crop").show();
		for (let i=0;i<screenshotNum;i++)
		{
			var dropdown_mark_div = document.getElementById('dropdown-menu-mark');
			let button_mark = document.createElement("button");
			button_mark.id = "btn_mark_"+(i+1);
			button_mark.classList.add('dropdown-item');
			button_mark.classList.add('text-center');
			let span1 = document.createElement('span');
			span1.className = 'fa fa-file-image-o text-primary'; 
			button_mark.appendChild(span1);
			button_mark.appendChild(document.createTextNode(' Image ' + (i + 1)));
			dropdown_mark_div.appendChild(button_mark);

			var dropdown_copy_div = document.getElementById('dropdown-menu-copy');
			let button_copy = document.createElement("button");
			button_copy.id = "btn_copy_"+(i+1);
			button_copy.classList.add('dropdown-item');
			button_copy.classList.add('text-center');
			let span2 = document.createElement('span');
			span2.className = 'fa fa-file-image-o text-primary';
			button_copy.appendChild(span2);
			button_copy.appendChild(document.createTextNode(' Image ' + (i + 1)));
			dropdown_copy_div.appendChild(button_copy);

			var dropdown_crop_div = document.getElementById('dropdown-menu-crop');
			let button_crop = document.createElement("button");
			button_crop.id = "btn_crop_"+(i+1);
			button_crop.classList.add('dropdown-item');
			button_crop.classList.add('text-center');
			let span3 = document.createElement('span');
			span3.className = 'fa fa-file-image-o text-primary'; 
			button_crop.appendChild(span3);
			button_crop.appendChild(document.createTextNode(' Image ' + (i + 1)));
			dropdown_crop_div.appendChild(button_crop);
		}

		for (let i=0;i<screenshotNum;i++)
		{
			$('#screenshot'+i).on('click', function() {
				zoomImgs(i);
			});

			$('#btn_mark_'+(i+1)).on('click', function() {
				if (viewThumbnail==1)
					zoomImgs(i);

				//console.log("openState[i]",openState[i]);
				if (openState[i]==0)
				{
					let element = document.getElementById('div_screenshot'+i);
					if (element) {  
						window.scrollTo({  
						top: element.offsetTop,
						behavior: 'smooth'
						});  
					} 
					//$('#screenshot'+i).trigger('click');
					showMarkerAreaEdit(i,document.getElementById('screenshot'+i));
				}
			});

			$('#btn_crop_'+(i+1)).on('click', function() {
				if (viewThumbnail==1)
					zoomImgs(i);

				let element = document.getElementById('div_screenshot'+i);
				if (element) {  
					window.scrollTo({  
					top: element.offsetTop,
					behavior: 'smooth'
					});  
				} 

				let _screenshot = document.getElementById('screenshot'+i);
				if (_screenshot && _screenshot.offsetHeight>9000)
				{
					showCropArea(_screenshot,i);
				}
				else if (_screenshot)
				{
					showCropArea(_screenshot,i);
				}
			});

			// $('#btn_crop').on('click', function() {
			// 	showTip(chrome.i18n.getMessage('noSupportMultiPic'));
			// });

			$('#btn_copy_'+(i+1)).on('click', function() {
				if (doing==0)
				{
					doing = 1;
					$('.icon_copy_load').show();
					$('.icon_copy').hide();
					let promises = [];
					if (openState[i] === 1)
					{
						promises.push(markerAreas[i].startRenderAndClose());  
					}  
					
					if (promises.length>0)
					{
						Promise.all(promises).then(() => {
							btn_copy_action(i);
						}).catch(error => { console.error(error); });
					}
					else
					{
						btn_copy_action(i);
					}

					setTimeout(function() {
						doing = 0;
						$('.icon_copy_load').hide();
						$('.icon_copy').show();
					},5000);
				}
			});
		}
	}
}


function btn_copy_action(index=0) {
	var imgElement = $('#screenshot'+index);

	if (imgElement.length === 0) {
		showTip('No Image');
		return;
	}

	var base64Data = imgElement.attr('src');

	var parts = base64Data.split(';base64,');
	var contentType = parts[0].split(":")[1];
	var data = parts[1];

	if (contentType === 'image/jpeg') {
		var canvas = document.createElement('canvas');
		var ctx = canvas.getContext('2d');

		var img = new Image();
		img.onload = function() {
			canvas.width = img.width;
			canvas.height = img.height;
			ctx.drawImage(img, 0, 0);

			canvas.toBlob(function(blob) {
				copyToClipboard(blob, 'image/png');
			}, 'image/png');
		};
		img.src = 'data:image/jpeg;base64,' + data;
	} else if (contentType === 'image/png') {
		// png copy
		var raw = window.atob(data); 
		var rawLength = raw.length;  
		var uInt8Array = new Uint8Array(rawLength);
		for (var i = 0; i < rawLength; ++i) {
			uInt8Array[i] = raw.charCodeAt(i);
		}
		// Base64 to Blob
		var blob = new Blob([uInt8Array], {type: contentType});
	
		// create ClipboardItem object
		var items = [new ClipboardItem({ "image/png": blob })];
		// to clipBoard
		navigator.clipboard.write(items).then(function() {
			showTip(chrome.i18n.getMessage('copyImageToClipBoardSuccess'));
		}).catch(function(err) {
			showTip(chrome.i18n.getMessage('copyImageToClipBoardFalse'));
		}); 

		doing = 0;
		$('.icon_copy_load').hide();
		$('.icon_copy').show();
	}
	
}

async function btn_download_action(index=0,directSave=0) {
	var base64Data = $('#screenshot'+index).attr('src');
	
	const storageitems = await getStorageLocal(['downloadImageFormat']);
	let downloadImageFormat = 'image/png';
	if (storageitems.downloadImageFormat)
		downloadImageFormat = storageitems.downloadImageFormat;

	console.log("downloadImageFormat",downloadImageFormat);

	var extendName = '.png';
	if (downloadImageFormat == 'image/jpeg')
		extendName = '.jpg';

	var blob = base64ToBlob(base64Data, downloadImageFormat);
	var url = URL.createObjectURL(blob);
	var _filename = 'CaptureX/' + sanitizeFileName(createFileName(index,extendName));
	if (directSave>0)
		_filename = sanitizeFileName(createFileName(index,extendName));

	if (directSave==1)
	{
		var a = document.createElement('a');  
		a.href = base64Data;
		a.download = _filename;
		document.body.appendChild(a);  
		a.click();
		document.body.removeChild(a); 
	}
	else{
		chrome.downloads.download({
			url: url,
			filename: _filename,
			saveAs: true
		}, function (downloadId) {
			console.log('Download initiated with ID: ' + downloadId);
		});
	}
}

$('#btn_download').on('click', function() {
	if (doing==0)
	{
		doing = 1;
		$('.icon_down_image_load').show();
		$('.icon_down_image').hide();

		if (screenshotNum>1) {
			let promises = [];

			for (let i=0;i<screenshotNum;i++)
			{
				if (openState[i] === 1)
					promises.push(markerAreas[i].startRenderAndClose());
			}

			if (promises.length>0)
			{
				Promise.all(promises).then(() => {
					for (let i=0;i<screenshotNum;i++)
					{
						btn_download_action(i,1);
					}
				}).catch(error => { console.error(error); });
			}
			else
			{
				for (let i=0;i<screenshotNum;i++)
				{
					btn_download_action(i,1);
				}
			}
		}
		else{
			const markerjs2_elements = document.querySelectorAll('.__markerjs2_');
			if (markerjs2_elements && markerjs2_elements.length>0)
			{
				markerAreas[0].startRenderAndClose().then(result => {
					chrome.storage.local.get({ downloadSaveAs: 'no' }, function(items) {
						if (items.downloadSaveAs=='yes')
							btn_download_action();
						else
							btn_download_action(0,1);
					});
				}).catch(error => { console.error(error); });
			}
			else{
				chrome.storage.local.get({ downloadSaveAs: 'no' }, function(items) {
					if (items.downloadSaveAs=='yes')
						btn_download_action();
					else
						btn_download_action(0,1);
				});
			}
		}
		setTimeout(function() {
			doing = 0;
			$('.icon_down_image_load').hide();
			$('.icon_down_image').show();
		},1000*screenshotNum);
	}
	else
	{
		console.log('btn_download bussy');
	}
});

async function btn_pdf_action() {
	var _filename = 'CaptureX/' + sanitizeFileName(createFileName(0,'.pdf'));

	let imgSrcArray = [];
	for (let i=0;i<screenshotNum;i++)
	{
		imgSrcArray.push($('#screenshot'+i).attr('src'));
	}

	let downloadSaveAs = 'no';
	let margin = 10; // PageMargin default 10pt
	await chrome.storage.local.get({ pdfPageMargin: 10 }, function(items) {
		margin = items.pdfPageMargin;
	});

	let pdfPageSize = 'a4'; // pageSize,letter,legal,a4,full
	await chrome.storage.local.get({ pdfPageSize: 'a4' }, function(items) {
		pdfPageSize = items.pdfPageSize;
	});

	const storageitems = await getStorageLocal(['pdfPageMargin','pdfPageSize','downloadSaveAs']);
	if (storageitems.pdfPageMargin)
		margin = Number(storageitems.pdfPageMargin);
	if (storageitems.pdfPageSize)
		pdfPageSize = storageitems.pdfPageSize;
	if (storageitems.downloadSaveAs)
		downloadSaveAs = storageitems.downloadSaveAs;

	//console.log("margin",margin);
	//console.log("pdfPageSize",pdfPageSize);
	//console.log("downloadSaveAs",downloadSaveAs);

	if (pdfPageSize=='full')
	{
		var imgData = imgSrcArray[0];
		var _filename = 'CaptureX/' + sanitizeFileName(createFileName(0,'.pdf'));
		var img = new Image();
		img.src = imgData;
		img.onload = function() {
			var imgWidth = img.width;
			var imgHeight = img.height;
			const { jsPDF } = window.jspdf;
			var pdf = new jsPDF({
				orientation: imgWidth > imgHeight ? 'landscape' : 'portrait',
				unit: 'px',
				format: [imgWidth, imgHeight]
			});
			pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);

			if (downloadSaveAs == 'yes')
			{
				//select save as path
				const pdfBlob = pdf.output('blob');
				const url = URL.createObjectURL(pdfBlob);
				chrome.downloads.download({
					url: url,
					filename: _filename,
					saveAs: true
				}, function (downloadId) {
					console.log('Download initiated with ID: ' + downloadId);
				});
			}
			else
			{
				_filename = sanitizeFileName(createFileName(0,'.pdf'));
				pdf.save(_filename); //save direct
			}
			doing = 0;
			$('.icon_down_pdf_load').hide();
			$('.icon_down_pdf').show();
		};
	}
	else
	{
		const { jsPDF } = window.jspdf;
		const pdf = new jsPDF('p', 'pt', pdfPageSize);
		const pdfPageWidth = pdf.internal.pageSize.getWidth();
		const pdfPageHeight = pdf.internal.pageSize.getHeight();
		const usablePageWidth = pdfPageWidth - 2 * margin;
		const usablePageHeight = pdfPageHeight - 2 * margin;
		
		for (const imgSrc of imgSrcArray) {
			const img = await loadImgObj(imgSrc);
			if (img){
				const imgWidth = img.width;
				const imgHeight = img.height;
				const scale = usablePageWidth / imgWidth;
				const scaledImgHeight = imgHeight * scale;
		
				let yOffset = 0;
				while (yOffset < imgHeight) {
					const remainingHeight = imgHeight - yOffset;
					const pageHeight = Math.min(remainingHeight, usablePageHeight / scale);
		
					const canvas = document.createElement('canvas');
					const ctx = canvas.getContext('2d');
					canvas.width = imgWidth;
					canvas.height = pageHeight;
		
					ctx.drawImage(img, 0, yOffset, imgWidth, pageHeight, 0, 0, imgWidth, pageHeight);
					const imgData = canvas.toDataURL('image/jpeg');
		
					if (yOffset > 0 || imgSrcArray.indexOf(imgSrc) > 0) {
						pdf.addPage();
					}
					pdf.addImage(imgData, 'JPEG', margin, margin, usablePageWidth, pageHeight * scale);
		
					yOffset += pageHeight;
				}
			}
		}
		if (downloadSaveAs == 'yes')
		{
			//select save as path
			const pdfBlob = pdf.output('blob');
			const url = URL.createObjectURL(pdfBlob);
			chrome.downloads.download({
				url: url,
				filename: _filename,
				saveAs: true
			}, function (downloadId) {
				console.log('Download initiated with ID: ' + downloadId);
			});
		}
		else
		{
			_filename = sanitizeFileName(createFileName(0,'.pdf'));
			pdf.save(_filename); //save direct
		}

		doing = 0;
		$('.icon_down_pdf_load').hide();
		$('.icon_down_pdf').show();
	}
	
}


function loadImgObj(imgData) {  
    return new Promise((resolve, reject) => {  
        const img = new Image();
        img.src = imgData; 
        img.onload = () => {
            resolve(img);  
        };  
        img.onerror = (error) => {
			console.error('Failed to load image:', error);
            resolve(null);
        };  
    });  
} 

$('#btn_pdf').click(function() {
	if (doing==0)
	{
		doing = 1;
		$('.icon_down_pdf_load').show();
		$('.icon_down_pdf').hide();

		if (screenshotNum>1) {
			let promises = [];
			for (let i=0;i<screenshotNum;i++)
			{
				if (openState[i] === 1)
					promises.push(markerAreas[i].startRenderAndClose());  
			}
			
			if (promises.length>0)
			{
				Promise.all(promises).then(() => {
					btn_pdf_action();
				}).catch(error => { console.error(error); });
			}
			else
			{
				btn_pdf_action();
			}
		}
		else{
			const markerjs2_elements = document.querySelectorAll('.__markerjs2_');
			if (markerjs2_elements && markerjs2_elements.length>0)
			{
				markerAreas[0].startRenderAndClose().then(result => {
					btn_pdf_action();
				}).catch(error => { console.error(error); });
			}
			else{
				btn_pdf_action();
			}
		}

		setTimeout(function() {
			doing = 0;
			$('.icon_down_pdf_load').hide();
			$('.icon_down_pdf').show();
		},5000);
	}
});

function btn_print_action(){
	let imgHtml = '';
	for (let i=0;i<screenshotNum;i++)
	{
		let imgData = $('#screenshot'+i).attr('src');
		
		if (screenshotNum==1)
		{
			imgHtml += '<img id="printableImage0" style="position: absolute; top 0; width:100%;" src="'+imgData+'" />';
		}
		else
		{
			imgHtml += '<div class="no-break"><img id="printableImage'+i+'" src="'+imgData+'" /></div>';
		}
	}

	const iframe = document.createElement('iframe');
	iframe.style.display = 'none';
	document.body.appendChild(iframe);

	const doc = iframe.contentWindow.document;

	doc.open();
	doc.write(`
		<html>
		<head>
			<title>Print Image</title>
			<style>
				body {
					margin: 0;
				}
				.no-break {
					page-break-inside: avoid;
					page-break-before: auto;
					page-break-after: auto;
            	}
				img {
					max-width: 100%;
					height: auto;
					display: block; 
					page-break-before: always;
				}
			</style>
		</head>
		<body style="padding:0px;">${imgHtml}</body>
		</html>
	`);
	doc.close();

	$(iframe).on('load', function() {
		doing=0;
		$('.icon_print_load').hide();
		$('.icon_print').show();
		iframe.contentWindow.focus();
		iframe.contentWindow.print();
	});

	$(iframe.contentWindow).on('afterprint', function() {
		$(iframe).remove();
	});
}

$('#btn_print').click(function() {
	if (doing==0)
	{
		doing = 1;
		$('.icon_print_load').show();
		$('.icon_print').hide();

		let promises = [];
		for (let i=0;i<screenshotNum;i++)
		{
			if (openState[i] === 1)
				promises.push(markerAreas[i].startRenderAndClose());  
		}
		
		Promise.all(promises).then(() => {
			btn_print_action();
		}).catch(error => { console.error(error); });

		setTimeout(function() {
			doing = 0;
			$('.icon_print_load').hide();
			$('.icon_print').show();
		},5000);
	}
});

$('#btn_report').click(function() {
	showReportWin();
});

function showTip(txt,seconds=2){
    var capturex_win_tip_div = document.createElement("div");
    capturex_win_tip_div.id = "capturex_win_tip_div";

    var tipDiv = document.createElement("div");
    tipDiv.style.cssText = "z-index: 2147483645; width: auto; height: auto; position:fixed; top:50%; left:50%; transform: translate(-50%, -50%); background-color: #000; opacity:0.8; padding: 10px 15px 10px 15px; border-radius: 4px; text-align: center; font-size:20px; color:#fff;";
    tipDiv.innerText = txt;

    capturex_win_tip_div.appendChild(tipDiv);
    document.body.appendChild(capturex_win_tip_div);
    setTimeout(function() {
        let _tipDiv = document.getElementById('capturex_win_tip_div');
        if (_tipDiv)
            document.body.removeChild(_tipDiv);
    },seconds*1000);
}

function hideTip()
{
    var capturex_win_tip_div = document.getElementById('capturex_win_tip_div');
    if (capturex_win_tip_div)
        capturex_win_tip_div.remove();
}

function base64ToBlob(base64Data, contentType) {  
    contentType = contentType || '';  
    var sliceSize = 1024;  
    var byteCharacters = atob(base64Data.split(',')[1]);  
    var bytesLength = byteCharacters.length;  
    var slicesCount = Math.ceil(bytesLength / sliceSize);  
    var byteArrays = new Array(slicesCount);  
  
    for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {  
        var begin = sliceIndex * sliceSize;  
        var end = Math.min(begin + sliceSize, bytesLength);  
  
        var bytes = new Array(end - begin);  
        for (var offset = begin, i = 0; offset < end; ++i, ++offset) {  
            bytes[i] = byteCharacters[offset].charCodeAt(0);  
        }  
        byteArrays[sliceIndex] = new Uint8Array(bytes);  
    }  
    return new Blob(byteArrays, {type: contentType});  
}

function copyToClipboard(blob, contentType) {
    // check browser Clipboard API
    if (!navigator.clipboard) {
        showTip(chrome.i18n.getMessage('copyNotSupport'));
        return;
    }

    var clipboardItem = new ClipboardItem({ [contentType]: blob });

    // write to clipboard
    navigator.clipboard.write([clipboardItem]).then(function() {
        showTip(chrome.i18n.getMessage('copyImageToClipBoardSuccess'));
		doing = 0;
		$('.icon_copy_load').hide();
		$('.icon_copy').show();
    }).catch(function(err) {
        showTip(chrome.i18n.getMessage('copyImageToClipBoardFalse'));
		doing = 0;
		$('.icon_copy_load').hide();
		$('.icon_copy').show();
    });
}

function resizeOrCompressImage(dataURL, maxWidth = 1920, quality = 0.9) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
            const width = img.width;
            const height = img.height;

            if (width > maxWidth) {
                const scaleFactor = maxWidth / width;
                const newWidth = maxWidth;
                const newHeight = height * scaleFactor;

                const canvas = document.createElement('canvas');
                canvas.width = newWidth;
                canvas.height = newHeight;

                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, newWidth, newHeight);

                const newDataURL = canvas.toDataURL('image/jpeg', 0.9); 
                canvas.remove();
                resolve(newDataURL);
            } else {
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                
                const newDataURL = canvas.toDataURL('image/jpeg', quality);
                canvas.remove();
                resolve(newDataURL);
            }
        };

        img.onerror = (error) => {
            reject(error);
        };
        img.src = dataURL;
    });
}

function getStorageLocal(keys) {  
	return new Promise((resolve, reject) => {  
		chrome.storage.local.get(keys, resolve);  
	});  
} 


function showReportWin(){
	if (document.getElementById('capturex_win_save_div'))
		document.body.removeChild(document.getElementById('capturex_win_save_div'));
	var capturex_win_save_div = document.createElement("div");
	capturex_win_save_div.id = "capturex_win_save_div";

	var iframe = document.createElement("iframe");
	iframe.id = "CaptureXIframe";
	iframe.src = chrome.runtime.getURL("html/report.html");
	iframe.style.cssText = "position: fixed; right: 10px; top: 60px; display: block; height: 490px; width: 380px; border: none; border-radius: 12px; box-shadow: rgba(35, 45, 71, 0.1) 0px 4px 8px 0px; z-index: 2147483647 !important;";

	capturex_win_save_div.appendChild(iframe);
	document.body.appendChild(capturex_win_save_div);
}

function closeWin(){
	if (document.getElementById('capturex_win_save_div'))
		document.body.removeChild(document.getElementById('capturex_win_save_div'));
}


var fileNameType = 'By Time';
chrome.storage.local.get({ fileNameSet: 'By Time' }, function(items) {
	fileNameType = items.fileNameSet;
});

document.addEventListener("visibilitychange", function() {
    if (document.visibilityState === "visible") {
        chrome.storage.local.get({ fileNameSet: 'By Time' }, function(items) {
			console.log('page back');
			fileNameType = items.fileNameSet;
		});
    }
});

function createFileName(index=0,extendName)
{
	let fileName;
	if (fileNameType && fileNameType=='By Title' && $('#fav_urltitle').val().length>0)
	{
		if (screenshotNum>1 && extendName!='.pdf')
		{
			fileName = sanitizeFileName($('#fav_urltitle').val() +'_'+(index+1));
		}
		else
		{
			fileName = sanitizeFileName($('#fav_urltitle').val());
		}
	}
	else
	{
		const now = new Date();
		const year = now.getFullYear();
		const month = String(now.getMonth() + 1).padStart(2, '0');
		const day = String(now.getDate()).padStart(2, '0');
		const hours = String(now.getHours()).padStart(2, '0');
		const minutes = String(now.getMinutes()).padStart(2, '0');
		const seconds = String(now.getSeconds()).padStart(2, '0');
		const formattedDate = `${year}-${month}-${day}_${hours}${minutes}${seconds}`;

		var domainName;
		var url = $('#fav_url').val();
		if (url && url.length>0)
		{
			domainName = getDomainFromUrl(url);
		}

		if (domainName && domainName.length>0)
		{
			fileName = 'CaptureX_'+formattedDate+'_'+domainName;
		}
		else
		{
			fileName = 'CaptureX_'+formattedDate;
		}

		if (screenshotNum>1 && extendName!='.pdf')
		{
			fileName = fileName+'_'+(index+1);
		}
	}

	return fileName+extendName;
}