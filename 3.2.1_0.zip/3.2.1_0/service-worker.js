﻿var contentjsIsLoad=0; //deprecated
var permissionAllSite=0;
var activeTab;
var nowShotImgData;
var allShotImgData0;
var allShotImgData0_index=0;
var allShotImgData0_index=0;
var allShotImgData1;
var allShotImgData1_index=0;
var allShotImgData2;
var allShotImgData2_index=0;
var allShotImgData3;
var allShotImgData3_index=0;
var allShotImgData4;
var allShotImgData4_index=0;
var allShotImgData5;
var allShotImgData5_index=0;
var allShotImgData6;
var allShotImgData6_index=0;
var allShotImgData7;
var allShotImgData7_index=0;
var linkText='';
var pageHtml='';
var capture2edit = 0; //When equal to 1, take a screenshot then enter the edit interface
var tab_title; 
var tab_url;

function reSetData() { //Reset global variables
  //console.log('reSetData');
  nowShotImgData = undefined;
  allShotImgData0 = undefined;
  allShotImgData0_index=0;
  allShotImgData1 = undefined;
  allShotImgData1_index=0;
  allShotImgData2 = undefined;
  allShotImgData2_index=0;
  allShotImgData3 = undefined;
  allShotImgData3_index=0;
  allShotImgData4 = undefined;
  allShotImgData4_index=0;
  allShotImgData5 = undefined;
  allShotImgData5_index=0;
  allShotImgData6 = undefined;
  allShotImgData6_index=0;
  allShotImgData7 = undefined;
  allShotImgData7_index=0;
  linkText='';
  pageHtml='';
  capture2edit = 0;
  tab_title = undefined;
  tab_url = undefined;
}

chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === 'install')
  {
    chrome.tabs.create({ url: chrome.runtime.getURL("html/about.html") });
  }
  else if (details.reason === 'update')
  {
    chrome.tabs.create({ url: chrome.runtime.getURL("html/about.html") });
  }
}); 

chrome.action.onClicked.addListener(function(tab) {
  //deprecated
});

chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if(tab)
    {
      activeTab = tab;
    }
    else
    {
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        activeTab = tabs[0];
      });
    }
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (activeTab && activeTab.id === tabId) {
    activeTab = tab;
  }

  if (changeInfo.status === "complete" && permissionAllSite==1) {
    if (checkTab(activeTab))
    {
      setTimeout(function() {  
        if (tabId==activeTab.id)
        {
          //console.log("executeScript content.js");
          chrome.scripting.executeScript({
            target: { tabId: activeTab.id },
            files: ['content.js']
          });
        }
      }, 100);
    }
  }
});

function checkTab(tab)
{
  if (tab && tab.url && tab.url.indexOf("chrome://")!=0 && tab.url.indexOf("edge://")!=0 && tab.url.indexOf("chrome-extension://")!=0 && tab.url.indexOf("https://chromewebstore.google.com/")!=0 && tab.url.indexOf("https://microsoftedge.microsoft.com/")!=0)
    return true;
  else
    return false;
}

function getActiveTab()
{
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    activeTab = tabs[0];
  });
}

getActiveTab();


chrome.permissions.contains(
  {
    origins: ["<all_urls>"],
  },
  (result) => {
    if (result) {
      //console.log("all all_urls")
      permissionAllSite = 1;
    }
    else
    {
      //console.log("not all all_urls")
      permissionAllSite = 0;
    }
  }
);


function sendMessageCheckContentJsIsLoad(message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      activeTab = tabs[0];
      if (checkTab(activeTab))
      {
        chrome.tabs.sendMessage(activeTab.id, message, (response) => {
          if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
          } else {
              resolve(response);
          }
        });
      }
    });
  });
}

//Listen messages from the content page
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
	if (message.action === 'contentjsIsLoad') {
		contentjsIsLoad=1;
	}
  else if (message.action === 'permissionAllSite') {
		permissionAllSite=message.value;
	}
  else if (message.action == 'checkContentJsIsLoad')
  {
    sendMessageCheckContentJsIsLoad({ action: 'checkContentLoaded' })
    .then((response) => {
        if (response && response.loaded !== undefined) {
            //console.log("response.loaded", response.loaded);
        }
    })
    .catch((error) => {
        //console.error("Failed to send message:", error);
        //console.log("executeScript content.js");
        chrome.scripting.executeScript({
          target: { tabId: activeTab.id },
          files: ['content.js']
        });
        
        if (activeTab && activeTab.status!=='complete')
        {
          setTimeout(function() {  
            chrome.scripting.executeScript({
              target: { tabId: activeTab.id },
              files: ['content.js']
            });
          }, 500);
        }
    });
  }
  else if (message.action == 'reSetData')
  {
    reSetData();
  }
  else if (message.action == 'capture2edit')
  {
    capture2edit = 1;
  }
  else if (message.action == 'openNewTab')
  {
    chrome.tabs.create({ url: message.url });
  }
  else if (message.action == 'openNewTabNoAcive')
  {
    chrome.tabs.create({ url: message.url,active: false });
  }
  else if (message.action == 'startGoogleLogin')
  {
    loginWithGoogle();
  }
  else if (message.action == 'startMicrosoftLogin')
  {
    loginWithMicrosoft();
  }
  else if (message.action == 'startAppleLogin')
  {
    loginWithApple();
  }
  else if (message.action === 'setSelectionCaptureData') //Received screenshot data of the selected area
  {
    allShotImgData0 = message.dataUrl;
    pageHtml = message.pageHtml;
    tab_title = activeTab.title;
    tab_url = activeTab.url;
    chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
  }
  else if (message.action === 'query_sendScreenshot')
  {
    if (allShotImgData0)
      chrome.tabs.sendMessage(activeTab.id, { action: 'sendScreenshot0', data: allShotImgData0});
    if (allShotImgData1)
      chrome.tabs.sendMessage(activeTab.id, { action: 'sendScreenshot1', data: allShotImgData1});
    if (allShotImgData2)
      chrome.tabs.sendMessage(activeTab.id, { action: 'sendScreenshot2', data: allShotImgData2});
    if (allShotImgData3)
      chrome.tabs.sendMessage(activeTab.id, { action: 'sendScreenshot3', data: allShotImgData3});
    if (allShotImgData4)
      chrome.tabs.sendMessage(activeTab.id, { action: 'sendScreenshot3', data: allShotImgData4});
    if (allShotImgData5)
      chrome.tabs.sendMessage(activeTab.id, { action: 'sendScreenshot3', data: allShotImgData5});
    if (allShotImgData6)
      chrome.tabs.sendMessage(activeTab.id, { action: 'sendScreenshot3', data: allShotImgData6});
    if (allShotImgData7)
      chrome.tabs.sendMessage(activeTab.id, { action: 'sendScreenshot3', data: allShotImgData7});

    chrome.tabs.sendMessage(activeTab.id, { action: 'page_data', url: tab_url, title: tab_title, pageHtml: pageHtml});
  }
  else if (message.action === 'openCaptureEditPage')
  {
    chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
  }
  else if (message.action === 'start_captureAllpageEdit')
  {
    captureAllPageEdit(activeTab);
  }
  else if (message.action === 'start_capturePageFromCurrentPosition')
  {
    capturePageFromCurrentPositionEdit(activeTab);
  }
  else if (message.action === 'captureVisiblePageScreenshot4Edit') {
    chrome.tabs.captureVisibleTab(null, {format: 'png'}, (dataUrl) => {
      allShotImgData0 = dataUrl;
      tab_title = activeTab.title;
      tab_url = activeTab.url;
      chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
    });
	}
  else if (message.action === 'captureVisiblePageScreenshot') {
    nowShotImgData = '';
		chrome.tabs.captureVisibleTab(function(screenshotData) {
      nowShotImgData = screenshotData;

      if (message.nextPageData)
        console.log(message.nextPageData);

      if (message.nextPageData)
        chrome.tabs.sendMessage(activeTab.id, { action: 'getNowShotImgData',y1:message.y1,y2:message.y2,nextPageData:message.nextPageData});
      else
        chrome.tabs.sendMessage(activeTab.id, { action: 'getNowShotImgData',y1:message.y1,y2:message.y2});
    });
	}
  else if (message.action === 'captureVisiblePageScreenshot4Selection') {
    nowShotImgData = '';
		chrome.tabs.captureVisibleTab(function(screenshotData) {
      nowShotImgData = screenshotData;
      chrome.tabs.sendMessage(activeTab.id, { action: 'getNowShotImgData4Selection',y1:message.y1,y2:message.y2});
    });
	}
  else if (message.action === 'captureVisiblePageScreenshot4SelectionCopy') {
    nowShotImgData = '';
		chrome.tabs.captureVisibleTab(function(screenshotData) {
      nowShotImgData = screenshotData;
      chrome.tabs.sendMessage(activeTab.id, { action: 'getNowShotImgData4SelectionCopy',y1:message.y1,y2:message.y2});
    });
	}
  else if (message.action === 'requestCaptureScreenshot') {//Front end page get screenshot data
	  sendResponse({ imageData: nowShotImgData,y1:message.y1,y2:message.y2});
	  nowShotImgData='';
    return true;
	}
  else if (message.action === 'imgDataChunk0'){//Receive screenshot data sent by content.js
    if (message.dataIndex==0)
    {
      allShotImgData0_index = 0;
      allShotImgData0='';
    }
    
    if (message.dataIndex==allShotImgData0_index)
    {
      allShotImgData0=allShotImgData0+message.dataItem;
      allShotImgData0_index++;
    }

    if (message.dataIndex==(message.dataLength-1) && message.hasNextImg==0)
    {
      if (capture2edit==1)
      {
        tab_title = activeTab.title;
        tab_url = activeTab.url;
        chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
      }
      else
        actionSavePage(activeTab); //Submit favorites and upload snapshot data to cloud
    }

    sendResponse({ rtn: 1,index:message.dataIndex});
    return true;
  }
  else if (message.action === 'imgDataChunk1'){//Receive screenshot1 data sent by content.js
    if (message.dataIndex==0)
    {
      allShotImgData1_index = 0;
      allShotImgData1='';
    }
    
    if (message.dataIndex==allShotImgData1_index)
    {
      allShotImgData1=allShotImgData1+message.dataItem;
      allShotImgData1_index++;
    }

    if (message.dataIndex==(message.dataLength-1) && message.hasNextImg==0)
    {
      if (capture2edit==1)
      {
        tab_title = activeTab.title;
        tab_url = activeTab.url;
        chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
      }
      else
        actionSavePage(activeTab);
    }

    sendResponse({ rtn: 1,index:message.dataIndex});
    return true;
  }
  else if (message.action === 'imgDataChunk2'){//Receive screenshot2 data sent by content.js
    if (message.dataIndex==0)
    {
      allShotImgData2_index = 0;
      allShotImgData2='';
    }
    
    if (message.dataIndex==allShotImgData2_index)
    {
      allShotImgData2=allShotImgData2+message.dataItem;
      allShotImgData2_index++;
    }

    if (message.dataIndex==(message.dataLength-1) && message.hasNextImg==0)
    {
      if (capture2edit==1)
      {
        tab_title = activeTab.title;
        tab_url = activeTab.url;
        chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
      }
      else
        actionSavePage(activeTab);
    }

    sendResponse({ rtn: 1,index:message.dataIndex});
    return true;
  }
  else if (message.action === 'imgDataChunk3'){//Receive screenshot3 data sent by content.js
    if (message.dataIndex==0)
    {
      allShotImgData3_index = 0;
      allShotImgData3='';
    }
    
    if (message.dataIndex==allShotImgData3_index)
    {
      allShotImgData3=allShotImgData3+message.dataItem;
      allShotImgData3_index++;
    }

    if (message.dataIndex==(message.dataLength-1) && message.hasNextImg==0)
    {
      if (capture2edit==1)
      {
        tab_title = activeTab.title;
        tab_url = activeTab.url;
        chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
      }
      else
        actionSavePage(activeTab);
    }

    sendResponse({ rtn: 1,index:message.dataIndex});
    return true;
  }
  else if (message.action === 'imgDataChunk4'){//Receive screenshot4 data sent by content.js
    if (message.dataIndex==0)
    {
      allShotImgData4_index = 0;
      allShotImgData4='';
    }
    
    if (message.dataIndex==allShotImgData4_index)
    {
      allShotImgData4=allShotImgData4+message.dataItem;
      allShotImgData4_index++;
    }

    if (message.dataIndex==(message.dataLength-1) && message.hasNextImg==0)
    {
      if (capture2edit==1)
      {
        tab_title = activeTab.title;
        tab_url = activeTab.url;
        chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
      }
      else
        actionSavePage(activeTab);
    }

    sendResponse({ rtn: 1,index:message.dataIndex});
    return true;
  }
  else if (message.action === 'imgDataChunk5'){//Receive screenshot5 data sent by content.js
    if (message.dataIndex==0)
    {
      allShotImgData5_index = 0;
      allShotImgData5='';
    }
    
    if (message.dataIndex==allShotImgData5_index)
    {
      allShotImgData5=allShotImgData5+message.dataItem;
      allShotImgData5_index++;
    }

    if (message.dataIndex==(message.dataLength-1) && message.hasNextImg==0)
    {
      if (capture2edit==1)
      {
        tab_title = activeTab.title;
        tab_url = activeTab.url;
        chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
      }
      else
        actionSavePage(activeTab);
    }

    sendResponse({ rtn: 1,index:message.dataIndex});
    return true;
  }
  else if (message.action === 'imgDataChunk6'){//Receive screenshot6 data sent by content.js
    if (message.dataIndex==0)
    {
      allShotImgData6_index = 0;
      allShotImgData6='';
    }
    
    if (message.dataIndex==allShotImgData6_index)
    {
      allShotImgData6=allShotImgData6+message.dataItem;
      allShotImgData6_index++;
    }

    if (message.dataIndex==(message.dataLength-1) && message.hasNextImg==0)
    {
      if (capture2edit==1)
      {
        tab_title = activeTab.title;
        tab_url = activeTab.url;
        chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
      }
      else
        actionSavePage(activeTab);
    }

    sendResponse({ rtn: 1,index:message.dataIndex});
    return true;
  }
  else if (message.action === 'imgDataChunk7'){//Receive screenshot7 data sent by content.js
    if (message.dataIndex==0)
    {
      allShotImgData7_index = 0;
      allShotImgData7='';
    }
    
    if (message.dataIndex==allShotImgData7_index)
    {
      allShotImgData7=allShotImgData7+message.dataItem;
      allShotImgData7_index++;
    }

    if (message.dataIndex==(message.dataLength-1) && message.hasNextImg==0)
    {
      if (capture2edit==1)
      {
        tab_title = activeTab.title;
        tab_url = activeTab.url;
        chrome.tabs.create({ url: chrome.runtime.getURL("html/capture_edit.html") });
      }
      else
        actionSavePage(activeTab);
    }

    sendResponse({ rtn: 1,index:message.dataIndex});
    return true;
  }
});


function genericOnClick(info, tab) {
  if (tab && tab.url && (tab.url.indexOf("chrome://")==0 || tab.url.indexOf("chrome-extension://")==0 || tab.url.indexOf("https://chromewebstore.google.com/")==0))
  {
    chrome.tabs.create({ url: chrome.runtime.getURL("html/about.html?msg=1") });
  }
  else if (tab && tab.url && (tab.url.indexOf("edge://")==0 || tab.url.indexOf("extension://")==0 || tab.url.indexOf("https://microsoftedge.microsoft.com/")==0))
  {
    chrome.tabs.create({ url: chrome.runtime.getURL("html/about.html?msg=1") });
  }
  else if (tab && tab.url)
  {
    sendMessageCheckContentJsIsLoad({ action: 'checkContentLoaded' })
    .then((response) => {
        if (response && response.loaded !== undefined) {
            console.log("response.loaded", response.loaded);
            genericOnClickAction(info, tab);
        }
    })
    .catch((error) => {
        //console.error("Failed to send message:", error);
        console.log("executeScript content.js");
        chrome.scripting.executeScript({
            target: { tabId: activeTab.id },
            files: ['content.js']
        });
        setTimeout(function() {  
          genericOnClickAction(info, tab);
        }, 100);
    });

  }
}

function genericOnClickAction(info, tab)
{
  switch (info.menuItemId) {
    case 'captureAllPage':
      reSetData();
      captureAllPageEdit(tab); //Capture entire page and Annotate
      break;
    case 'capturePage':
      reSetData();
      capturePageEdit(tab); //Capture visible part and Annotate
      break;
    case 'captureSelection':
      reSetData();
      captureSelectionEdit(tab); //Capture selection and Annotate
      break;
    default:
      break;
  }
}

function captureAllPageEdit(tab)
{
  startCapturePageScreenshot(tab); //Capture entire page
  capture2edit = 1; //After completion, enter the editing interface
}

function capturePageFromCurrentPositionEdit(tab)
{
  startCapturePageFromCurrentPosition(tab); //Capture pages from current position
  capture2edit = 1; //After completion, enter the editing interface
}

function capturePageEdit(tab)
{
  activeTab = tab;
  chrome.tabs.sendMessage(tab.id, { action: 'capturePageEdit'});
}

function captureSelectionEdit(tab)
{
  activeTab = tab;
  chrome.tabs.sendMessage(tab.id, { action: 'captureSelectionEdit'});
}

//Start screenshot of the entire webpage
function startCapturePageScreenshot(tab)
{
	activeTab = tab;
  chrome.tabs.sendMessage(tab.id, { action: 'captureAllPageScreenshot'});
}

function startCapturePageFromCurrentPosition(tab)
{
	activeTab = tab;
  chrome.tabs.sendMessage(tab.id, { action: 'capturePageScreenshotFromCurrentPosition'});
}

//
function actionSavePage(tab)
{
  //save to yeskeeper
  //save to google drive
  //save to drive one
}

//YesKeeper OAuth 2.0 log in
function loginWithGoogle() {
  const clientId = '621831986975-3q2s1kerqpv57oul7338bu4nrhs74g22.apps.googleusercontent.com';
  const redirectUri = 'https://yeskeeper.com/googleLoginCallback.do';
  const scope = "openid profile email";
  const authUrl = `https://accounts.google.com/o/oauth2/auth?` +
        `client_id=${clientId}` +
        `&response_type=code` +
        `&redirect_uri=${encodeURIComponent(redirectUri)}` +
        `&scope=${encodeURIComponent(scope)}`;

  setTimeout(function() {  
    chrome.tabs.create({ url: authUrl });
  }, 600);
}


function loginWithMicrosoft() {
  const clientId = '2650214d-67b8-499b-af39-f9dbac8fcd8e';
  const redirectUri = 'https://yeskeeper.com/microsoftLoginCallback.do';
  const scope = "openid profile email";
  const authUrl = `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?` +
        `client_id=${clientId}` +
        `&response_type=code` +
        `&redirect_uri=${encodeURIComponent(redirectUri)}` +
        `&scope=${encodeURIComponent(scope)}`;

  setTimeout(function() {  
    chrome.tabs.create({ url: authUrl });
  }, 600);
}

function loginWithApple() {
  const clientId = 'com.webman.yeskeeper.chromeextension';
  const redirectUri = 'https://yeskeeper.com/appleLoginCallback.do';
  //console.log("redirectUri",redirectUri);
  const scope = "name email";
  const authUrl = `https://appleid.apple.com/auth/authorize?` +
        `client_id=${clientId}` +
        `&response_type=code` +
        `&redirect_uri=${encodeURIComponent(redirectUri)}` +
        `&scope=${encodeURIComponent(scope)}` + 
        `&response_mode=form_post`;

  setTimeout(function() {  
    chrome.tabs.create({ url: authUrl });
  }, 600);
}
