﻿//right win size
var rightWidth = 360;
var goUrl_chrome = 'https://chromewebstore.google.com/detail/lbndmgmpidplehmebcfkokbappanjmip';
var goUrl_edge = 'https://microsoftedge.microsoft.com/addons/detail/kjfnpkngmjgpmhfldijhoaplhkfehpcj';

function showRightWin() {
	let htmlContent = '';
	htmlContent += '<div id="rightWin_capturex" style="overflow: visible; padding: 0px; margin: 0px; z-index: 2147483647; width: '+rightWidth+'px; height: auto; background:#FFF; position: fixed; bottom: 0px; right: 0px;">';
	htmlContent += '	<div class="card">';
	htmlContent += '		<div class="card-header">'+chrome.i18n.getMessage('like_title')+'</div>';
	htmlContent += '		<div class="card-body">'+chrome.i18n.getMessage('like_body')+'</div>';
	htmlContent += '		<div class="card-footer text-right">';
	htmlContent += '		<button type="button" id="like_no_thanks" class="btn mr-2">'+chrome.i18n.getMessage('like_no_thanks')+'</button>';
	htmlContent += '		<button type="button" id="like_yes" class="btn btn-info mr-2">'+chrome.i18n.getMessage('like_yes')+'</button></div>';
	htmlContent += '	</div>';

	htmlContent += '	<div id="rightWin_close_div" style="position: absolute; overflow: visible; z-index: 2147483647; padding: 0px; margin: 0px; top: 10px; left: '+(rightWidth-30)+'px; height: 26px; width: 26px; line-height: 26px; text-align: center;">';
	htmlContent += '		<a id="close_rightWin" style="color: rgb(0, 0, 0); text-decoration: none; cursor: pointer; padding: 6px;"><svg t="1742737592067" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2807" width="16" height="16"><path d="M4.43392 97.36192l90.5088-90.5088 923.18976 923.18976-90.5088 90.5088-923.18976-923.18976ZM930.04288 4.43392l90.5088 90.5088-923.18976 923.18976-90.5088-90.5088 923.18976-923.18976Z" fill="#272636" p-id="2808"></path></svg></a>';
	htmlContent += '	</div>';
	htmlContent += '</div>';
	document.body.insertAdjacentHTML('beforeend', htmlContent);

	if (document.documentElement.getAttribute("dir")=="rtl")
	{
		$('#rightWin_close_div').css('left', '10px');
		$('#rightWin_capturex .card-header').addClass('text-right');
		$('#rightWin_capturex .card-body').addClass('text-right');
	}

	$('#like_no_thanks').on('click', function() {
		close_rightWin();
	});

	$('#close_rightWin').on('click', function() {
		close_rightWin();
	});

	$('#like_yes').on('click', function() {
		close_rightWin();
		let goUrl = goUrl_chrome;
		const userAgent = navigator.userAgent.toLowerCase();
		if (userAgent.includes("edg/")) {
			goUrl = goUrl_edge;
		}
		chrome.tabs.create({ url: goUrl });
	});
}

function close_rightWin()
{
	const element = document.getElementById('rightWin_capturex');
	if (element)
		element.remove();
}