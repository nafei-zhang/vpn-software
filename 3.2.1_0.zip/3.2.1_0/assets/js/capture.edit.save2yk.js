	var homeUrl = 'https://yeskeeper.com';

	function showSave2yeskeeperForm()
	{
		content='';
		content+='<form name="favForm" id="favForm">';

		content+='<div class="input-group mb-2">';
		content+='  <div class="input-group-prepend">';
		content+='    <span class="input-group-text">'+chrome.i18n.getMessage('favUrl')+'</span>';
		content+='  </div>';
		content+='  <input readonly type="text" class="form-control"  name="url" id="fav_url" value="">';
		content+='</div>';

		content+='<div class="input-group mb-2">';
		content+='  <div class="input-group-prepend">';
		content+='    <span class="input-group-text">'+chrome.i18n.getMessage('favTitle')+'</span>';
		content+='  </div>';
		content+='  <input type="text" class="form-control" autocomplete="off" placeholder="'+chrome.i18n.getMessage('favTitle')+'" name="urltitle" id="fav_urltitle" value="">';
		content+='</div>';

		content+='<div class="input-group fav_tags mb-2">';
		content+='  <div class="input-group-prepend">';
		content+='    <span class="input-group-text">'+chrome.i18n.getMessage('favTag')+'</span>';
		content+='  </div>';
		content+='  <input type="text" class="form-control" autocomplete="off" placeholder="'+chrome.i18n.getMessage('favTagPlaceholder')+'" type="text" name="tags" id="fav_tags" value="">';
		content+='</div>';
		
		content+='<div id="accordion" class="tag_sel mb-2" style="max-height:16rem">';
		content+=' <div class="card mb-0" style="border: 1px solid rgba(0,0,0,.125);border-radius: .25rem;box-shadow: 0 0 0 rgba(0, 0, 0, 0.1);">';
		content+='  <div class="card-header d-flex flex-wrap align-items-center">';
		content+='    <a class="card-link flex-shrink-0 pr-2" style="color: #495057;" data-toggle="collapse" href="#collapseOne">';
		content+='      '+chrome.i18n.getMessage('favMyTags')+'<span class="forOther2"> ('+chrome.i18n.getMessage('clickSel')+')</span>';
		content+='    </a>';
		content+='    <div class="flex-grow-1 mt-md-0" style="width:4rem;">';
		content+='    <input type="text" id="searchTags" class="float-right form-control form-control-sm rounded-y ml-1 tag-search" placeholder="Search" />';
		content+='    </div>';
		content+='  </div>';
		content+='  <div id="collapseOne" class="collapse show" data-parent="#accordion">';
		content+='    <div id="myTagSel" class="card-body pt-1 pb-1" style="line-height:2rem;height:7rem;overflow:auto;"></div>';
		content+='  </div>';
		content+=' </div>';
		content+=' <div id="sugguest_tags" class="card mb-0" style="border: 1px solid rgba(0,0,0,.125);border-radius: .25rem;box-shadow: 0 0 0 rgba(0, 0, 0, 0.1);display:none">';
		content+='  <div class="card-header">';
		content+='    <a class="collapsed card-link" style="color: #495057;" data-toggle="collapse" href="#collapseTwo">';
		content+='    '+chrome.i18n.getMessage('favSuggestTag')+'<span class="forOther2"> ('+chrome.i18n.getMessage('clickSel')+')</span>';
		content+='  </a>';
		content+='  </div>';
		content+='  <div id="collapseTwo" class="collapse" data-parent="#accordion">';
		content+='    <div id="mySuggestTagSel" class="card-body pt-1 pb-1" style="line-height:2rem;height:7rem;overflow:auto;"></div>';
		content+='  </div>';
		content+=' </div>';

		content+=' <div class="card mb-1 mt-2" style="border: 1px solid rgba(0,0,0,.125);border-radius: .25rem;box-shadow: 0 0 0 rgba(0, 0, 0, 0.1);">';
		content+='  <div class="card-header">';
		content+='    <a class="collapsed card-link" style="color: #495057;" data-toggle="collapse" href="#collapseThree">';
		content+='    '+chrome.i18n.getMessage('privateBeizhu')+'<span class="forOther2"> ('+chrome.i18n.getMessage('clickUnfold')+')</span>';
		content+='  </a>';
		content+='  </div>';
		content+='  <div id="collapseThree" class="collapse" data-parent="#accordion">';
		content+='	  <div class="mb-3 pt-2 fav_beizhu_d">';
		content+='      <textarea rows="3" class="form-control" style="resize:none" placeholder="'+chrome.i18n.getMessage('privateBeizhu')+'--'+chrome.i18n.getMessage('optional')+'" name="beizhu" id="fav_beizhu" value=""></textarea>';
		content+='	  </div>';
		content+='  </div>';
		content+=' </div>';

		content+='</div>';
		
		
		content+='<input type="hidden" name="ispub" id="fav_ispub" value="1"/>';
		content+='<input type="hidden" name="client" id="fav_client" value="extension"/>';
		content+='<input type="hidden" name="rank" id="fav_rank" value="1"/>';
		content+='<input type="hidden" name="saveCatch" id="saveCatch" value="1"/>';
		content+='<input type="hidden" name="zhaiId" id="zhaiId" value="0"/>';
		content+='<input type="hidden" name="urlId" id="urlId" value="0"/>';
		content+='<div class="text-left pt-2 pb-1">';
		content+='<span class="ml-1">'+chrome.i18n.getMessage('favOption')+' : <span>';
		content+='<a id="btn_favBtnSnap" class="ml-1 p-1" data-toggle="tooltip" data-placement="top" title="'+chrome.i18n.getMessage('captureAsSnapshotUpload')+'"><span class="fa fa-camera favBtnSnap"></span></a>';
		content+='<a id="btn_favBtnLock" class="ml-1 p-1" data-toggle="tooltip" data-placement="top" title="'+chrome.i18n.getMessage('saveUrl2PrivateInfo')+'"><span class="fa fa-lock forOther favBtnLock"></span></a>';
		
		content+='<div class="form-check float-right ml-1">';
		content+='<a href="https://yeskeeper.com/v5/my_set" data-toggle="tooltip" data-placement="top" title="'+chrome.i18n.getMessage('settings')+'" target="_blank" id="btn_setting"><li id="setbtn" class="fa fa-gear"></li></a>';
		content+='</div>';

		content+='</div>';
		content+='<div id="showValidateCode"></div>';
		content+='<div id="saveFavErrorMsg"></div>';
		content+='</form>';
		$("#save2yeskeeper").html(content);

		// Filter tags on input event
		$("#searchTags").keyup(function(){
			filterMyTags();
		});

		$('#btn_addFav').on('click', function() {
			if (isLogin==1)
				addFav();
			else
				showLoginWin();
		});

		$('#btn_favBtnLock').on('click', function() {
			setUrlFavLock();
		});

		$('#btn_favBtnSnap').on('click', function() {
			setFavSnap();
		});

		// setTimeout(() => {
		// 	getSuggestTagSel();
		// }, 500);
	}

	// Function to filter tags based on input
	function filterMyTags() {
		const searchInput = document.getElementById("searchTags");
		const myTagSel = document.getElementById("myTagSel");
		const links = myTagSel.querySelectorAll("a");
		const query = searchInput.value.toLowerCase();
		links.forEach(link => {
			if (link.textContent.toLowerCase().includes(query)) {
				link.style.display = "inline-block"; // Show matching links
			} else {
				link.style.display = "none"; // Hide non-matching links
			}
		});
	}

	function showTagSel()
	{
		if ($(".tag_sel").css("max-height")=="0rem" || $(".tag_sel").css("max-height")=="0px")
			$(".tag_sel").css("max-height","16rem");
		else
			$(".tag_sel").css("max-height","0px");
	}

	function getUserTagSel()
	{
		if ($("#myTagSel").html()=='')
		{
			$("#myTagSel").html('<span class="fa fa-spinner fa-spin"></span>');
			$.ajax({  
				type: "get",  
				url: homeUrl+"/getUserTagsJsonAction.do",
				cache: false,
				success: function(data){
					if (data && data.rtn==1)
					{
						$("#myTagSel").empty();
						data.data.forEach(item => {
							let element = $('<a>', {
								id: 'usertag_'+item.tagId,
								class: 'p-1 ml-1 colorb',
								text: item.tagTagName
							});
							$("#myTagSel").append(element);
							$(element).click(function(){
								selectTag(item.tagId);
							});
						});
					}
					else
					{
						$("#myTagSel").empty();
					}
				},
				error: function(data){
				}
			}); 
		}
	}

	function getSuggestTagSel()
	{
		if ($("#mySuggestTagSel").html()=='')
		{
			$("#mySuggestTagSel").html('<span class="fa fa-spinner fa-spin"></span>');
			$.ajax({  
				type: "get",  
				url: homeUrl+"/getSuggestTagsJsonAction.do?url="+encodeURIComponent($("#fav_url").val()),
				cache: false,
				success: function(data){
					if (data && data.rtn==1)
					{
						$("#mySuggestTagSel").empty();
						data.data.forEach(item => {
							let element = $('<a>', {
								id: 'tag_'+item.tagId,
								class: 'p-1 ml-1 colorb',
								text: item.tagTagName
							});
							$("#mySuggestTagSel").append(element);
							$(element).click(function(){
								selectTag(item.tagId);
							});
						});
					}
					else
					{
						$("#mySuggestTagSel").empty();
					}
				},
				error: function(data){
				}
			}); 
		}
	}

	function showFavIntroInput()
	{
		$("#text-info .nav-link").removeClass("active");
		$("#showFavIntroInput").addClass("active");
		
		$(".fav_beizhu_d").addClass("d-none");
		$(".fav_intro_d").removeClass("d-none");
	}

	function showBeizhuInput()
	{
		$("#text-info .nav-link").removeClass("active");
		$("#showBeizhuInput").addClass("active");
		
		$(".fav_beizhu_d").removeClass("d-none");
		$(".fav_intro_d").addClass("d-none");
	}
	
	function setFavSnap()
	{
		if ($(".favBtnSnap").hasClass("forOther"))
		{
			$(".favBtnSnap").removeClass("forOther");
			$(".favBtnSnap").addClass("colorb");
			$("#saveCatch").val(1);
		}
		else
		{
			$(".favBtnSnap").addClass("forOther");
			$(".favBtnSnap").removeClass("colorb");
			$("#saveCatch").val(0);
		}
		$(".favBtnSnap").blur();
	}

	function setUrlFavLock()
	{
		if ($(".favBtnLock").hasClass("forOther"))
		{
			$(".favBtnLock").removeClass("forOther");
			$(".favBtnLock").addClass("colorb");
			$("#fav_ispub").val(0);
		}
		else
		{
			$(".favBtnLock").addClass("forOther");
			$(".favBtnLock").removeClass("colorb");
			$("#fav_ispub").val(1);
		}
		$(".favBtnLock").blur();
	}

	/*-------------
	select tag
	--------------------*/
	var firstSel=1;
	var maxTags=3;
	function selectTag(tagId)
	{
		if (firstSel==1)
		{
			firstSel=0;
			$("#fav_tags").val("");
		}
		obj1=document.getElementById("usertag_"+tagId);
		obj2=document.getElementById("tag_"+tagId);
		
		var tagName;
		if (obj1)
			tagName=obj1.textContent;
		else if (obj2)
			tagName=obj2.textContent;

		var tags=$("#fav_tags").val();

		if ((tags+' ').indexOf(tagName+' ')>-1)
		{
			try
			{
				delTag(tagName);
				if (obj1!=null)
					obj1.style.backgroundColor='#f5F5f5';
				if (obj2!=null)
					obj2.style.backgroundColor='#f5F5f5';
				
				if ($("#usertag_"+tagId).length>0)
					$("#usertag_"+tagId).css("color","");
				if ($("#tag_"+tagId).length>0)
					$("#tag_"+tagId).css("color","");
			}
			catch(e){}
			
		}
		else
		{
			if (getLen(tagName)>28)
			{
				alert(chrome.i18n.getMessage('favTagLengthOver'));
			}
			else if (getTagsNum(tags) > (maxTags-1))
			{
				if (maxTags>=10)
					alert(chrome.i18n.getMessage('favTagNumOver'));
				else
					alert(chrome.i18n.getMessage('favTagNumOver'));
			}
			else
			{
				try
				{
					addTag(tagName);
					if (obj1!=null)
						obj1.style.backgroundColor='#3399ff';
					if (obj2!=null)
						obj2.style.backgroundColor='#3399ff';
					
					if ($("#usertag_"+tagId).length>0)
						$("#usertag_"+tagId).css("color","#fff");
					if ($("#tag_"+tagId).length>0)
						$("#tag_"+tagId).css("color","#fff");
				}
				catch(e){}
			}
		}

	}

	function addTag(tagName)
	{
		var tagName1 = " "+tagName+" ";
		var tags=$("#fav_tags").val();
		tags=" "+reFormatTags(tags);

		if (tags.indexOf(tagName1)==-1)
		{
			try
			{
				tags=tags+tagName+" ";
				var _tags = reFormatTags(tags);
				$("#fav_tags").val(_tags);
			}
			catch(e){}
		}
		tags=reFormatTags(tags);
	}

	function delTag(tagName)
	{
		var tagName1 = " "+tagName+" ";
		var tags=$("#fav_tags").val();
		tags=" " + reFormatTags(tags);
		if (tags.indexOf(tagName1)>-1)
		{
			try
			{
				tags=tags.replace(tagName1,' ');
				$("#fav_tags").val(reFormatTags(tags));
			}
			catch(e){}
		}
		tags=reFormatTags(tags);
	}

	function getTagsNum(tags)
	{
		var allTag = reFormatTags(tags);
		var num=0;
		while(allTag.indexOf(" ")>=0)
		{
			allTag = allTag.replace(" ","");
			num++;
		}
		return num;
	}

	function reFormatTags (tags)
	{
		if (tags!=null)
		{
			if (tags=="")
				return tags;
			else
			{		
				tags = replaceAll(tags,"、"," ");
				tags = replaceAll(tags,"，"," ");
				tags = replaceAll(tags,","," ");
				tags = replaceAll(tags,"　", " ");
				tags = replaceAll(tags,"  "," ");
				
				return trim(tags)+" ";
			}
		}
		return "";
	}

	function addFav(){
		if (doing==0)
		{
			doing = 1;
			document.getElementById('btn_addFav').disabled = true;
			$("#saveFavErrorMsg").html('<div id="uploadSnap_info"><span class="fa fa-spinner fa-spin"></span></div>');
			var formData = $("#favForm").serialize();
			$.ajax({
				type: "POST",
				url: homeUrl+"/addFavJson.do",
				cache: false,
				data: formData,
				success: function(data){
					document.getElementById('btn_addFav').disabled = false;
					if (data.rtn==1)
					{
						console.log("fav save success");
						$("#saveFavErrorMsg").html('');
						$("#btn_addFav").hide();
						$("#btn_my").show();
						if (typeof showTip === 'function') {
							showTip(chrome.i18n.getMessage("fav_success"));
						}

						if (data.zhaiId>0)
							$("#zhaiId").val(data.zhaiId);
						if (data.urlId>0)
							$("#urlId").val(data.urlId);

						if (data.snapId>0)
						{
							console.log("uploadSnap");
							$("#saveFavErrorMsg").html('<div id="uploadSnap_info">'+chrome.i18n.getMessage("snap_shot_uploading") +'<span class="fa fa-spinner fa-spin"></span></div>');
							uploadSnap(pageHtml,$("#fav_url").val());
						}
					}
					else
					{
						$('#saveFavErrorMsg').text(data.msg);
						if (data.needActive && data.needActive==1)
						{
							setTimeout(function() {  
							try {
								chrome.tabs.create({url: homeUrl+"/email_check"});
							} catch (e) {}
							}, 1500);
						}
						else if (data.needLogin && data.needLogin==1)
						{
							isLogin = 0;
							showLoginWin();
						}
					}
				},
				error: function(data){
					var msg_content = chrome.i18n.getMessage("net_error");
					document.getElementById('saveFavErrorMsg').innerHTML = msg_content;
					document.getElementById('btn_addFav').disabled = false;
				}
			});

			setTimeout(function() {
				doing = 0;
			},5000);
		}
	}

	var isUploading = false; 
	// Listen beforeunload
	window.addEventListener('beforeunload', function (e) { 
	  if (isUploading) {
		console.log('User is trying to leave the page while upload is in progress.');
		e.preventDefault();  
		e.returnValue = '';
	  }  
	}); 

	function uploadSnapAction(imgData,htmlContent,url) {
		isUploading = true;  
		setTimeout(() => {
			isUploading = false;  
			console.log('Upload completed');  
		}, 20000);

		resizeOrCompressImage(imgData).then(newDataURL => {
			//newDataURL
			const fileName = 'image.jpg';
			const blob = base64ToBlob(newDataURL,'image/jpeg');
			const file = new File([blob], fileName, { type: blob.type });
		
			const formData = new FormData();
			formData.append('img', file, fileName);
			formData.append('url', url);
			formData.append('htmlContent', htmlContent);
		
			fetch(homeUrl+'/uploadSnapImgAction.do', {
			method: 'POST',
			body: formData
			})
			.then(response => response.json())
			.then(data => {
			isUploading = false;
			if (data.rtn==1)
			{
				console.log('uploadSnap success');
				$("#saveFavErrorMsg").html(chrome.i18n.getMessage("fav_success"));
			}
			else if (data.msg)
			{
				console.log('uploadSnap false');
				$("#saveFavErrorMsg").html(data.msg);
			}
			else{
				console.log('uploadSnap false');
				$("#saveFavErrorMsg").html(chrome.i18n.getMessage("error_upload_snap"));
			}
			allShotImgData = '';
			allShotImgData_index = 0;
			pageHtml = '';
			hideTip();
			})
			.catch(error => {
				isUploading = false;
				$("#saveFavErrorMsg").html(chrome.i18n.getMessage("error_upload_snap"));
			});
		}).catch(error => {
			console.error('image upload error:', error);
			isUploading = false;
			hideTip();
			showTip('image upload error');
		});
	}

	function uploadSnap(htmlContent,url) {
		showTip(chrome.i18n.getMessage("snap_shot_uploading"),20);
		const markerjs2_elements = document.querySelectorAll('.__markerjs2_');
        if (markerjs2_elements && markerjs2_elements.length>0)
        {
            markerArea.startRenderAndClose().then(result => {  
                console.log('success'); 
				let screenshot = document.getElementById('screenshot');
                uploadSnapAction(screenshot.src,htmlContent,url)
            }).catch(error => {  
                console.error(error);  
            });;
        }
        else
        {
			let screenshot = document.getElementById('screenshot');
            uploadSnapAction(screenshot.src,htmlContent,url);
        }
	}

	function checkUser(){
		fetch(homeUrl+'/getUserBoJsonAction.do', {
		  method: 'GET'
		})
	  .then(response => response.json())
	  .then(data => {
		if (data.rtn==1)
		{
			isLogin = 1;
			getUserTagSel();
			if (data.data.ispub==0 && $("#fav_ispub").val()==1)
			{
			  setUrlFavLock();
			}
			
		}
	  })
	  .catch(error => {
	  });
	}