//Filter spaces and carriage returns
function trim(str)
{
    if (str)
    {
        for(var i = 0; i<str.length && str.charAt(i)==" "; i++ ) ;
        for(var j =str.length; j>0 && str.charAt(j-1)==" "; j--)  ;
        if(i>j) return "";  
        return str.substring(i,j);
    }
    else
        return "";
}

function trimR(str)
{
    if (str)
    {
        var rt =/[\r\n]/g;
        var newStr=str.replace(rt,"");
        return newStr;
    }
    else
        return "";
}

function replaceAll(source, oldString, newString)
{
    var output=source;
    while(output.indexOf(oldString)>=0)
    {
        output = output.replace(oldString,newString);
    }
    return output;
}

function getLen(str) {
    var len = 0;
    for (var i=0; i<str.length; i++) {
      if (str.charCodeAt(i) > 127)
       len += 2;
      else 
       len++;
    }
    return len;
}

function getDomainFromUrl(url) {  
    try {  
        const urlObj = new URL(url);   
        const hostnameWithPort = urlObj.hostname;  
        const parts = hostnameWithPort.split(':');  
        return parts[0]; 
    } catch (error) {
        console.error('Invalid URL:', error);  
        return '';  
    }
}

//String truncation, extra long with ellipsis, East Asian characters count as 2 lengths
function truncateString(str, maxLength) { 
    const avgCharLength = 1.5;  
    
    const targetLength = Math.floor(maxLength / avgCharLength);  

    let realLength = 0;  
    const chars = Array.from(str);  
    for (let i = 0; i < chars.length; i++) { 
        if (chars[i].charCodeAt(0) >= 0x4e00 && chars[i].charCodeAt(0) <= 0x9fff) {  
            realLength += 2; 
        } else {  
            realLength++;
        }  
 
        if (realLength > targetLength) {  
            break;  
        }  
    }  

    const truncatedStr = chars.slice(0, targetLength).join('');  

    if (truncatedStr.length < str.length) {  
        return truncatedStr + '...';  
    }  
    return str;  
}  

//Filter special characters in file names
function sanitizeFileName(fileName) {
    const invalidChars = /[\\/*?:"<>|]/g;
    const sanitizedFileName = fileName.replace(invalidChars, '_');  
    return sanitizedFileName;  
}  

function string2Json(s) 
{     
    var newstr = "";
    if (s && s.length>0)
    {
        for (var i=0; i<s.length; i++) 
        {  
            c = s.charAt(i);       
            switch (c) {       
                case '\"':       
                    newstr+="\\\"";       
                    break;       
                case '\\':       
                    newstr+="\\\\";       
                    break;       
                case '/':       
                    newstr+="\\/";       
                    break;       
                case '\b':       
                    newstr+="\\b";       
                    break;       
                case '\f':       
                    newstr+="\\f";       
                    break;       
                case '\n':       
                    newstr+="\\n";       
                    break;       
                case '\r':       
                    newstr+="\\r";       
                    break;       
                case '\t':       
                    newstr+="\\t";       
                    break;       
                default:       
                    newstr+=c;       
            }  
       } 
    }
    return newstr;       
}

function detectAndSetDirection() {
    const lang = navigator.language || navigator.userLanguage;
    if (lang.startsWith('ar') || lang.startsWith('fa') || lang.startsWith('ur')) {
        document.documentElement.setAttribute("dir", "rtl");
    } else {
        document.documentElement.setAttribute("dir", "ltr");
    }
}