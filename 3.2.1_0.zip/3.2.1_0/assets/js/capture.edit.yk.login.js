var homeUrl = 'https://yeskeeper.com';

//for yeskeeper login
const currentLocale = chrome.i18n.getUILanguage();
if (currentLocale && currentLocale=='zh-CN')
{
  $('.openLogin').hide();
  $('.siteInfo').show();
}
$('#msg_name').text(chrome.i18n.getMessage('savePage2YesKeeperCom'));
$('#msg_site_item1').text(chrome.i18n.getMessage('site_item1'));
$('#msg_site_item2').text(chrome.i18n.getMessage('site_item2'));
$('#msg_site_item3').text(chrome.i18n.getMessage('site_item3'));
$('#loginBtn').text(chrome.i18n.getMessage('site_login'));
$('#regBtn').text(chrome.i18n.getMessage('site_reg'));
$('#emailPswLoginSubmit').text(chrome.i18n.getMessage('site_login'));
$('#forgetPsw').text(chrome.i18n.getMessage('forgetPsw'));
$('#btn_chanage_emailPswReg').text(chrome.i18n.getMessage('site_reg'));
$('#btn_chanage_emailPswLogin').text(chrome.i18n.getMessage('site_login'));
$('#emailPswRegSubmit').text(chrome.i18n.getMessage('site_reg'));

$('#emailCodeSubmit').text(chrome.i18n.getMessage('sendMailCode'));
$('#emailCodeSubmited').text(chrome.i18n.getMessage('loginCodeSent'));
$('#emailCodeLoginRegSubmit').text(chrome.i18n.getMessage('loginSignUp'));
$('#accountLogin').text(chrome.i18n.getMessage('accountLogin'));
$('.signUpAgreement').html(chrome.i18n.getMessage('signUpAgreement'));

$('.btnGoogleLogin_text').text(chrome.i18n.getMessage('signInWithGoogle'));
$('.btnMicrosoftLogin_text').text(chrome.i18n.getMessage('signInWithMicrosoft'));
$('.btnAppleLogin_text').text(chrome.i18n.getMessage('signInWithApple'));

function showLoginWin()
{
  $("#yeskeeper_overlay").show();
  $("#yeskeeper_loginWin").show();
}

function closeLoginWin()
{
  $("#yeskeeper_overlay").hide();
  $("#yeskeeper_loginWin").hide();
}

$(".closeLoginWin").on('click', function() {
  closeLoginWin();
});

$('.btnGoogleLogin').on('click', function() {
  $('.btnGoogleLogin_icon').hide();
  $('.btnGoogleLogin_loading').show();
  $('.btnGoogleLogin').prop('disabled', true);
  isLogin = 1;
  chrome.runtime.sendMessage({ action: 'startGoogleLogin' });
  setTimeout(function() {
    $('.btnGoogleLogin_icon').show();
    $('.btnGoogleLogin_loading').hide();
    $('.btnGoogleLogin').prop('disabled', false);
    closeLoginWin();
    if ($('.main-wrapper').length>0 && $('#load').length>0)
    {
      $("#load").html('<button id="refresh" class="btn btn-outline-primary btn-lg rounded-y mt-3 ml-2 mr-2 btn-block" type="button">'+getMessage("login_refresh")+'</button>');
      $("#refresh").on("click",function(){
        location.reload();
      });
    }
  },1000);
});

$('.btnMicrosoftLogin').on('click', function() {
  $('.btnMicrosoftLogin_icon').hide();
  $('.btnMicrosoftLogin_loading').show();
  $('.btnMicrosoftLogin').prop('disabled', true);
  isLogin = 1;
  chrome.runtime.sendMessage({ action: 'startMicrosoftLogin' });
  setTimeout(function() {
    $('.btnMicrosoftLogin_icon').show();
    $('.btnMicrosoftLogin_loading').hide();
    $('.btnMicrosoftLogin').prop('disabled', false);
    closeLoginWin();
    if ($('.main-wrapper').length>0 && $('#load').length>0)
    {
      $("#load").html('<button id="refresh" class="btn btn-outline-primary btn-lg rounded-y mt-3 ml-2 mr-2 btn-block" type="button">'+getMessage("login_refresh")+'</button>');
      $("#refresh").on("click",function(){
        location.reload();
      });
    }
  },1000);
});

$('.btnAppleLogin').on('click', function() {
  $('.btnAppleLogin_icon').hide();
  $('.btnAppleLogin_loading').show();
  $('.btnAppleLogin').prop('disabled', true);
  isLogin = 1;
  chrome.runtime.sendMessage({ action: 'startAppleLogin' });
  setTimeout(function() {
    $('.btnAppleLogin_icon').show();
    $('.btnAppleLogin_loading').hide();
    $('.btnAppleLogin').prop('disabled', false);
    closeLoginWin();
    if ($('.main-wrapper').length>0 && $('#load').length>0)
    {
      $("#load").html('<button id="refresh" class="btn btn-outline-primary btn-lg rounded-y mt-3 ml-2 mr-2 btn-block" type="button">'+getMessage("login_refresh")+'</button>');
      $("#refresh").on("click",function(){
        location.reload();
      });
    }
  },1000);
});

$("#loginBtn").click(function(){
  $("#div_index").hide();
  $("#emailPswReg").hide();
  $("#emailPswLogin").show();
});

$("#btn_chanage_emailPswLogin").click(function(){
  $("#div_index").hide();
  $("#emailPswReg").hide();
  $("#emailPswLogin").show();
});

$("#regBtn").click(function(){
  $("#div_index").hide();
  $("#emailPswLogin").hide();
  $("#emailPswReg").show();
});

$("#btn_chanage_emailPswReg").click(function(){
  $("#div_index").hide();
  $("#emailPswLogin").hide();
  $("#emailPswReg").show();
});

$(".email").focus(function(){
  if ($(".randomCode").length>0 && $(".randomCode").first().val()=='')
  {
    var qUrl=homeUrl+"/ajax_session?rnd="+Math.random();
    $.get(qUrl, {}, function(data) {
      var resultStr=data.replace(/[\r\n]/g,"");
      $(".randomCode").val(resultStr);
    });
    setInterval(getRandomCode, 60000*5);
  }
});

async function getRandomCode() {
  var qUrl=homeUrl+"/ajax_session?rnd="+Math.random();
  $.get(qUrl, {}, function(data) {
    var resultStr=data.replace(/[\r\n]/g,"");
    $(".randomCode").val(resultStr);
  });
}

//for emailPswLogin
var login_submiting = 0;
$("#emailPswLoginForm").submit(function(ev){
  ev.preventDefault();
  $("#emailPswLogin_doInfo").html('<span class="fa fa-spinner fa-spin"></span>');
  $("#emailPswLogin_doInfo").show();
  var formData = $("#emailPswLoginForm").serialize();
  if (login_submiting==0)
  {
    login_submiting = 1;
     $.ajax({
      type: "POST",
      url: homeUrl+"/LoginJsonAction.do",
      cache: false,
      data: formData,
      success: function(data, status){
        login_submiting=0;
        if(data && data.rtn==1){
          console.log("login success");
          login_submiting = 0;
          $("#emailPswLogin_doInfo").empty();
          isLogin=1;
          closeLoginWin();

          if (typeof reFrashValidateCode === "function")
          {
            reFrashValidateCode();
          }

          if (typeof getUserTagSel === "function")
          {
            getUserTagSel();
            if (data.data.ispub==0 && $("#fav_ispub").val()==1)
            {
              setUrlFavLock();
            }
          }

          if ($('.main-wrapper').length>0)
          {
            location.reload();
          }
        }
        else
        {
          if (data && data.msg)
          {
            $("#emailPswLogin_doInfo").html(data.msg);
            $("#emailPswLogin_doInfo").show();
          }
        
          if (data && data.needImgCode && data.needImgCode==1)
          {
            reFrashValidateCode_emailPswLogin();
          }
          else
          {
            if ($("#div_emailPswLogin_needValidateCode").is(":visible"))
            {
              reFrashValidateCode_emailPswLogin();
            }
          }
          
        }
      },
      error: function(data, status){
        $("#emailPswLogin_doInfo").html(chrome.i18n.getMessage("submitFalse"));
      }
     });
  }
  return false;
});

$("#btn_validatecodeImg_emailPswLogin").click(function(){
  reFrashValidateCode_emailPswLogin();
});

function reFrashValidateCode_emailPswLogin()
{
  console.log("reFrashValidateCode_emailPswLogin");
  $("#div_emailPswLogin_needValidateCode").show();
  document.getElementById("validatecodeImg_emailPswLogin").src=homeUrl+"/KValidateCode.serverlet?rnd="+Math.random();
  document.getElementById("emailPswLogin_validateCode").value="";
  $("#emailPswLogin_validateCode").focus();
}


//for emailPswReg
var reg_submiting = 0;
$("#emailPswRegForm").submit(function(ev){
  ev.preventDefault();
  $("#emailPswReg_doInfo").html('<span class="fa fa-spinner fa-spin"></span>');
  $("#emailPswReg_doInfo").show();
  var formData = $("#emailPswRegForm").serialize();
  if (reg_submiting==0)
  {
    reg_submiting = 1;
     $.ajax({
      type: "POST",
      url: homeUrl+"/register.do",
      cache: false,
      data: formData,
      success: function(data, status){
        reg_submiting=0;
        if(data && data.rtn==1){
          reg_submiting = 0;
          $("#emailPswReg_doInfo").empty();
          console.log("reg success");
          isLogin=1;
          closeLoginWin();

          if (typeof reFrashValidateCode === "function")
          {
            reFrashValidateCode();
          }

          if (typeof getUserTagSel === "function")
          {
            getUserTagSel();
          }

          if ($('.main-wrapper').length>0)
          {
            location.reload();
          }
        }
        else
        {
          if (data && data.msg)
          {
            $("#emailPswReg_doInfo").html(data.msg);
            $("#emailPswReg_doInfo").show();
          }
        
          if (data && data.needImgCode && data.needImgCode==1)
          {
            reFrashValidateCode_emailPswReg();
          }
          else
          {
            if ($("#div_emailPswReg_needValidateCode").is(":visible"))
            {
              reFrashValidateCode_emailPswReg();
            }
          }
          
        }
      },
      error: function(data, status){
        $("#emailPswReg_doInfo").html(chrome.i18n.getMessage("submitFalse"));
      }
     });
  }
  return false;
});

$("#btn_validatecodeImg_emailPswReg").click(function(){
  reFrashValidateCode_emailPswReg();
});

function reFrashValidateCode_emailPswReg()
{
  console.log("reFrashValidateCode_emailPswReg");
  $("#div_emailPswReg_needValidateCode").show();
  document.getElementById("validatecodeImg_emailPswReg").src=homeUrl+"/KValidateCode.serverlet?rnd="+Math.random();
  document.getElementById("emailPswReg_validateCode").value="";
  $("#emailPswReg_validateCode").focus();
}

//for emailCodeLoginReg
$("#emailCodeLoginRegSubmit").click(function(){
  var formData = $("#emailCodeLoginRegForm").serialize();
  if ($("#emailCodeLoginRegSubmit").html().indexOf(chrome.i18n.getMessage('loginSignUp'))>-1)
  {
    $("#emailCodeLoginRegSubmit").html('<i class="fa fa-spinner fa-spin" aria-hidden="true"></i>');
    $("#emailCodeLoginReg_doInfo").html('');
    $("#emailCodeLoginReg_doInfo").hide();
    $.ajax({  
     type: "POST",  
     url: homeUrl+"/emailRegister.do",
     cache: false,
     data: formData,
     success: function(data, status){
       $("#emailCodeLoginRegSubmit").html(chrome.i18n.getMessage("loginSignUp"));
      if (data && data.rtn==1)
      {
        console.log("login reg success");
        isLogin=1;
        closeLoginWin();

        if (typeof reFrashValidateCode === "function")
        {
          reFrashValidateCode();
        }

        if ($('.main-wrapper').length>0)
        {
          location.reload();
        }
      }
      else if (data && data.rtn==0)
      {
        if (data.msg)
        {
          $("#emailCodeLoginReg_doInfo").html("<div style=\"text-align:left;\">"+data.msg+"</div>");
          $("#emailCodeLoginReg_doInfo").show();
        }
        else
          alert(chrome.i18n.getMessage("errorNo"));
      }
      else
        alert(getMessage("error_no"));
     },
     error: function(data, status){
      $("#emailCodeLoginRegSubmit").html(chrome.i18n.getMessage("loginSignUp"));
      $("#emailCodeLoginReg_doInfo").html(chrome.i18n.getMessage("submitFalse"));
     }  
    }); 
  }
  return false;
});


$("#btn_validatecodeImg_emailCodeLoginReg").click(function(){
  reFrashValidateCode_emailCodeLoginReg();
});

function reFrashValidateCode_emailCodeLoginReg()
{
  console.log("reFrashValidateCode_emailCodeLoginReg");
  $("#div_emailCodeLoginReg_needValidateCode").show();
  document.getElementById("validatecodeImg_emailCodeLoginReg").src=homeUrl+"/KValidateCode.serverlet?rnd="+Math.random();
  document.getElementById("emailCodeLoginReg_validateCode").value="";
  $("#emailCodeLoginReg_validateCode").focus();
}

var emailSending=0;
var emailSendSecond=100;
var emailSendAgainTimer;
$("#emailCodeSubmit").click(function(){
  var formData = $("#emailCodeLoginRegForm").serialize();
  if (emailSending==0)
  {
    emailSending = 1;
    $("#emailCodeSubmit").html('<i class="fa fa-spinner fa-spin" aria-hidden="true"></i>');
    $("#emailCodeLoginReg_doInfo").html("");
    $.ajax({  
     type: "POST",  
     url: homeUrl+"/sendMailCodeAction.do",
     cache: false,  
     data: formData,  
     success: function(data, status){
      $("#emailCodeSubmit").html(chrome.i18n.getMessage("sendMailCode"));
      console.log(data);
       if(data.rtn==0){
        emailSending=0;
        $("#emailCodeSubmit").show();
        $("#emailCodeLoginReg_doInfo").html("<div style=\"text-align:left;\">"+data.msg+"</div>");
        $("#emailCodeLoginReg_doInfo").show();
        if (data.needImgCode && data.needImgCode==1)
        {
          reFrashValidateCode_emailCodeLoginReg();
        }
      }
      else
      {
        emailSending=2;
        $("#emailCodeSubmit").hide();
        $("#emailCodeSubmited").show();
        emailSendSecond=100;
        emailSendAgainTimer=window.setInterval(function(){
          emailSendSecond--;
          if ($("#emailCodeSubmited .ui-btn-text") && $("#emailSubmited .ui-btn-text").length>0)
            $("#emailCodeSubmited .ui-btn-text").html(chrome.i18n.getMessage("loginCodeResend")+"("+emailSendSecond+")");
          else
            $("#emailCodeSubmited").html(chrome.i18n.getMessage("loginCodeResend")+"("+emailSendSecond+")");
          if (emailSendSecond==0)
          {
            window.clearInterval(emailSendAgainTimer);
            emailSending=0;
            $("#emailCodeSubmited").hide();
            $("#emailCodeSubmit").show();
          }
        }, 1000);
      }
     },
     error: function(data, status){
      $("#emailSubmit").html(chrome.i18n.getMessage("sendMailCode"));
      emailSending=0;
       alert(getMessage("submitFalse"));
     }
    }); 
  }
  return false;
});


